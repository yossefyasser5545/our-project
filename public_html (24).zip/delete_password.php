<?php include "settings_logined.php" ?>
<?php
include "db_connection.php";

// 2. استلام الـ ID من الرابط عبر GET
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // 3. التحقق من أن الـ ID هو رقم
    if (is_numeric($id)) {
        // 4. استعلام الحذف
        $sql = "DELETE FROM passwords WHERE id = $id";

        // تنفيذ الاستعلام
        if ($conn->query($sql) === TRUE) {
            echo "Record deleted successfully";
        } else {
            echo "Error deleting record: " . $conn->error;
        }
    } else {
        echo "Invalid ID";
    }
} else {
    echo "ID not provided";
}

header("location: settings.php");
// 5. غلق الاتصال بقاعدة البيانات
$conn->close();
?>
