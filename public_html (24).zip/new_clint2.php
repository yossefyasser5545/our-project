<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'db_connection.php';

function generateUniqueCode($conn) {
    do {
        $code = str_pad(rand(0, 9999), 4, '0', STR_PAD_LEFT);
        $query = "SELECT COUNT(*) FROM clients WHERE clint_code = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $code);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close();
    } while ($count > 0);
    return $code;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $last_name = $_POST['last_name'];
    $first_name = $_POST['first_name'];
    $user_address = $_POST['user_address'];
    $user_email = $_POST['user_email'];
    $national_id = $_POST['national_id'];
    $phone_number = $_POST['phone_number'];
    $profession = $_POST['profession'];
    $monthly_income = $_POST['monthly_income'];
    $birth_date = $_POST['birth_date'];
    $total_amount = $_POST['total_amount'];
    $advance = $_POST['advance'];
    $delay = $_POST['delay'];
    $first_pay_date = $_POST['first_pay_date'];
    $kest_value = $_POST['kest_value'];
    $adition_notes = $_POST['adition_notes'];
    $bank_name = $_POST['bank_name'];

    $email_check_query = "SELECT COUNT(*) FROM clients WHERE email = ?";
    $stmt = $conn->prepare($email_check_query);
    $stmt->bind_param("s", $user_email);
    $stmt->execute();
    $stmt->bind_result($email_exists);
    $stmt->fetch();
    $stmt->close();

    if ($email_exists > 0) {
        header("Location: email_exists.html");
        exit();
    }

    $file_name = 'default_image.png';
    if (isset($_FILES['user_image']) && $_FILES['user_image']['error'] == 0) {
        $file = $_FILES['user_image'];
        $file_name = $file['name'];
        $file_tmp = $file['tmp_name'];
        $upload_dir = 'uploads/user_imgs/';
        move_uploaded_file($file_tmp, $upload_dir . $file_name);
    }

    $clint_code = generateUniqueCode($conn);

    $query = "INSERT INTO clients (first_name, last_name, email, phone_number, address, image_path, clint_code, national_id, profession, birth_date, monthly_income) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);

    if ($stmt) {
        $stmt->bind_param("sssssssssss", $first_name, $last_name, $user_email, $phone_number, $user_address, $file_name, $clint_code, $national_id, $profession, $birth_date, $monthly_income);

        if ($stmt->execute()) {
            $user_id = $conn->insert_id;

            $log_query = "INSERT INTO installments (total_amount, kest_value, upfront, deferred, first_pay_date, client_id, additional_notes, bank_name) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $log_stmt = $conn->prepare($log_query);

            if ($log_stmt) {
                $log_stmt->bind_param("ddddsiss", $total_amount, $kest_value, $advance, $delay, $first_pay_date, $user_id, $adition_notes, $bank_name);

                if ($log_stmt->execute()) {
                    $installment_id = $conn->insert_id;

                    $date_query = "INSERT INTO dates (date) VALUES (?)";
                    $date_stmt = $conn->prepare($date_query);

                    if ($date_stmt) {
                        $first_pay_date = date("Y-m-d H:i:s");
                        $date_stmt->bind_param("s", $first_pay_date);

                        if ($date_stmt->execute()) {
                            $date_id = $conn->insert_id;
                        } else {
                            echo 'Error in date insertion: ' . $conn->error;
                            $date_stmt->close();
                            exit;
                        }
                        $date_stmt->close();
                    } else {
                        echo 'Error preparing date statement: ' . $conn->error;
                        exit;
                    }

                    $advance_query = "INSERT INTO advances (installment_id, client_id, advance_value, advance_date, is_paid, paid_at) 
                                    VALUES (?, ?, ?, ?, ?, ?)";
                    $advance_stmt = $conn->prepare($advance_query);

                    if ($advance_stmt) {
                        $is_paid = 1;
                        $paid_at = date("Y-m-d H:i:s");
                        $advance_stmt->bind_param("iiidsi", $installment_id, $user_id, $advance, $date_id, $is_paid, $paid_at);

                        if (!$advance_stmt->execute()) {
                            echo 'Error in advance insertion: ' . $conn->error;
                        }
                        $advance_stmt->close();
                    } else {
                        echo 'Error preparing advance statement: ' . $conn->error;
                    }

                    $remaining_amount = $total_amount - ($advance + $delay);
                    $x = ceil($remaining_amount / $kest_value);
                    $last_installment_value = $remaining_amount - ($kest_value * ($x - 1));
                    $current_date = $first_pay_date;

                    $sub_query = "INSERT INTO sub_installments (installment_id, installment_value, client_id, is_paid, paid_at, sub_installment_date) 
                                VALUES (?, ?, ?, ?, ?, ?)";
                    $sub_stmt = $conn->prepare($sub_query);

                    if ($sub_stmt) {
                        for ($i = 1; $i <= $x; $i++) {
                            $installment_value = ($i == $x) ? $last_installment_value : $kest_value;
                            $is_paid = 0;
                            $paid_at = null;

                            $sub_installment_date = date("Y-m-d", strtotime("+1 month", strtotime($current_date)));
                            $current_date = $sub_installment_date;

                            $sub_stmt->bind_param("idisss", $installment_id, $installment_value, $user_id, $is_paid, $paid_at, $sub_installment_date);

                            if (!$sub_stmt->execute()) {
                                echo 'Error in sub installment insertion: ' . $conn->error;
                                break;
                            }
                        }
                        $sub_stmt->close();
                    }

                    $last_sub_installment_date = $current_date;
                    $insert_date_query = "INSERT INTO dates (date) VALUES (?)";
                    $date_stmt = $conn->prepare($insert_date_query);

                    if ($date_stmt) {
                        $new_date = date("Y-m-d", strtotime("+1 month", strtotime($last_sub_installment_date)));
                        $date_stmt->bind_param("s", $new_date);

                        if ($date_stmt->execute()) {
                            $delay_date_id = $conn->insert_id;
                            $date_stmt->close();

                            $delay_query = "INSERT INTO delays (installment_id, client_id, delay_value, delay_date, is_paid) 
                                            VALUES (?, ?, ?, ?, ?)";
                            $delay_stmt = $conn->prepare($delay_query);

                            if ($delay_stmt) {
                                $due_date = date("Y-m-d", strtotime("+30 days"));
                                $is_paid = 0;
                                $delay_stmt->bind_param("iiids", $installment_id, $user_id, $delay, $delay_date_id, $is_paid);

                                if (!$delay_stmt->execute()) {
                                    echo 'Error in delay insertion: ' . $conn->error;
                                }
                                $delay_stmt->close();
                            } else {
                                echo 'Error in preparing delay query: ' . $conn->error;
                            }
                        } else {
                            echo 'Error in inserting delay date: ' . $conn->error;
                        }
                    } else {
                        echo 'Error in preparing date query: ' . $conn->error;
                    }
                }
                $log_stmt->close();
            }
        }
        $stmt->close();
    }

}

header("location: clients.php");

$conn->close();
?>
