    function addPopup() {
        let currentUrl = window.location.href;
        if (!currentUrl.includes("?")) {
            window.location.href = currentUrl + "?popup=notifications";
        } else if (!currentUrl.includes("popup=notifications")) {
            window.location.href = currentUrl + "&popup=notifications";
        }
    }

    // التحقق من وجود ?popup=notifications في URL وعرض قائمة الإشعارات
    function checkPopup() {
        let currentUrl = window.location.href;
        if (currentUrl.includes("popup=notifications")) {
            document.getElementById('notificationList').style.display = 'block';
            document.querySelector('.over-layer').style.display = "block";
        } else {
            document.getElementById('notificationList').style.display = 'none';
            document.querySelector('.over-layer').style.display = "none";
        }
    }

    // عند الضغط خارج قائمة الإشعارات يتم إغلاقها وإزالة ?popup=notifications
    window.onclick = function(event) {
        let notificationList = document.getElementById('notificationList');
        if (event.target !== notificationList && !notificationList.contains(event.target)) {
            notificationList.style.display = 'none';
            document.querySelector('.over-layer').style.display = "none";
            let currentUrl = window.location.href.split("?")[0]; // إزالة الاستعلام من URL
            window.history.pushState({}, '', currentUrl);
        }
    };

    // استدعاء دالة checkPopup عند تحميل الصفحة
    window.onload = checkPopup;

    function confirmLogout() {
        // عرض رسالة التأكيد
        let confirmAction = confirm("هل أنت متأكد أنك تريد تسجيل الخروج؟");
        // التحقق إذا ضغط المستخدم على "موافق"
        if (confirmAction) {
            // توجيه المستخدم إلى صفحة PHP بعد التأكيد
            window.location.href = "logout.php"; // استبدل بـ صفحة الـ PHP الخاصة بك
        }
    }

    function addPopup() {
        let currentUrl = window.location.href;
        if (!currentUrl.includes("?")) {
            window.location.href = currentUrl + "?popup=notifications";
        } else if (!currentUrl.includes("popup=notifications")) {
            window.location.href = currentUrl + "&popup=notifications";
        }
    }
    
    // التحقق من وجود ?popup=notifications في URL وعرض قائمة الإشعارات
    function checkPopup() {
        let currentUrl = window.location.href;
        if (currentUrl.includes("popup=notifications")) {
            document.getElementById('notificationList').style.display = 'block';
            document.querySelector('.over-layer').style.display = "block";
        } else {
            document.getElementById('notificationList').style.display = 'none';
            document.querySelector('.over-layer').style.display = "none";
        }
    }
    
    
    
    // عند الضغط خارج قائمة الإشعارات يتم إغلاقها وإزالة ?popup=notifications
    window.onclick = function(event) {
        let notificationList = document.getElementById('notificationList');
        if (event.target !== notificationList && !notificationList.contains(event.target)) {
            notificationList.style.display = 'none';
            document.querySelector('.over-layer').style.display = "none";
            let currentUrl = window.location.href.split("?")[0]; // إزالة الاستعلام من URL
            window.history.pushState({}, '', currentUrl);
        }
    };
    
    // استدعاء دالة checkPopup عند تحميل الصفحة
    window.onload = checkPopup;

    
// التحقق من وجود باراميتر "popup" في URL
function removePopupFromURL() {
    const url = new URL(window.location.href);

    // إذا كان باراميتر popup موجودًا، قم بحذفه
    if (url.searchParams.has('popup')) {
        url.searchParams.delete('popup');
        
        // تحديث الـ URL بدون إعادة تحميل الصفحة
        window.history.replaceState(null, '', url);
    }
}

// استدعاء الدالة لإزالة باراميتر popup




    document.querySelector('.close-list').addEventListener("click", function(){
        removePopupFromURL();
         document.getElementById('notificationList').style.display = 'none';
        document.querySelector('.over-layer').style.display = "none";
});

function addPopup() {
    let currentUrl = window.location.href;
    if (!currentUrl.includes("?")) {
        window.location.href = currentUrl + "?popup=notifications";
    } else if (!currentUrl.includes("popup=notifications")) {
        window.location.href = currentUrl + "&popup=notifications";
    }
}

// التحقق من وجود ?popup=notifications في URL وعرض قائمة الإشعارات
function checkPopup() {
    let currentUrl = window.location.href;
    if (currentUrl.includes("popup=notifications")) {
        document.getElementById('notificationList').style.display = 'block';
        document.querySelector('.over-layer').style.display = "block";
    }
}

// عند الضغط خارج قائمة الإشعارات يتم إغلاقها وإزالة ?popup=notifications
window.onclick = function(event) {
    let notificationList = document.getElementById('notificationList');
    if (event.target !== notificationList && !notificationList.contains(event.target)) {
        notificationList.style.display = 'none';
        document.querySelector('.over-layer').style.display = "none";
        let currentUrl = window.location.href.split("?")[0]; // إزالة الاستعلام من URL
        window.history.pushState({}, '', currentUrl);
    }
};

// استدعاء دالة checkPopup عند تحميل الصفحة
window.onload = checkPopup;


function submitSearch() {
    var searchInput = document.getElementById('serch_input').value;
    if (searchInput.trim() !== "") {
        var url = new URL(window.location.href);
        url.searchParams.set('search-place', searchInput);
        window.location.href = url.href;
    }
}

function toggleInstallments(userId, button) {
    const installmentsRow = document.getElementById("installments-" + userId);
    if (installmentsRow.style.display === "none") {
        installmentsRow.style.display = "table-row";
    } else {
        installmentsRow.style.display = "none";
    }
}



const icons = document.querySelectorAll('.rotate-icon');

icons.forEach(icon => {
    icon.addEventListener('click', function() {
        this.classList.toggle('rotated');
    });
});

setupSlider('eksatContainer', 'toLeft', 'toRight');

// إعدادات الأقساط المدفوعة
setupSlider('eksatContainerPaid', 'toLeftPaid', 'toRightPaid');

function setupSlider(containerId, leftButtonId, rightButtonId) {
    const eksatContainer = document.getElementById(containerId);
    const toLeft = document.getElementById(leftButtonId);
    const toRight = document.getElementById(rightButtonId);

    let translateX = 0;
    const containerWidth = eksatContainer.parentElement.offsetWidth; // عرض الحاوية الأم
    const innerContainerWidth = eksatContainer.scrollWidth; // عرض المحتوى الداخلي

    function checkButtons() {
        if (translateX >= 0) {
            toLeft.style.display = 'none';
        } else {
            toLeft.style.display = 'flex';
        }

        if (Math.abs(translateX) >= innerContainerWidth - containerWidth) {
            toRight.style.display = 'none';
        } else {
            toRight.style.display = 'flex';
        }
    }

    checkButtons();

    toLeft.addEventListener('click', () => {
        translateX += 365; // تحريك البطاقات إلى اليمين
        eksatContainer.style.transform = `translateX(${translateX}px)`;
        checkButtons();
    });

    toRight.addEventListener('click', () => {
        translateX -= 365; // تحريك البطاقات إلى اليسار
        eksatContainer.style.transform = `translateX(${translateX}px)`;
        checkButtons();
    });
}

function deleteClient(clientId) {
    if (confirm("هل أنت متأكد من أنك تريد حذف هذا العميل؟")) {
        // إرسال الطلب إلى الخادم باستخدام AJAX
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "delete_client.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        
        // إرسال id العميل
        xhr.send("client_id=" + clientId);
        
        // بعد انتهاء العملية
        xhr.onload = function () {
            if (xhr.status === 200) {
                alert("تم حذف العميل بنجاح.");
                // إزالة العميل من الجدول دون إعادة تحميل الصفحة
                var row = document.querySelector('tr[data-user-id="' + clientId + '"]');
                row.remove();
                var installmentsRow = document.querySelector('#installments-' + clientId);
                if (installmentsRow) {
                    installmentsRow.remove();
                }
            } else {
                alert("حدث خطأ أثناء الحذف.");
            }
        };
    }
}
