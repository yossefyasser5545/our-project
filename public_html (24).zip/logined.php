<?php
// بدء الجلسة
session_start();

// التحقق إذا كانت الجلسة موجودة (هل تم إدخال كلمة السر أم لا)
if (isset($_SESSION['password_verified']) && $_SESSION['password_verified'] === true) {
    // إذا كانت الجلسة موجودة، يعنى أن كلمة السر تم التحقق منها
    // echo "تم إدخال كلمة السر بنجاح!";
} else {
    // إذا لم تكن الجلسة موجودة، يعنى أنه لم يتم إدخال كلمة السر
    echo "لم تقم بإدخال كلمة السر بعد!";
    header("location: enter_password.php");
    exit;
}
?>
