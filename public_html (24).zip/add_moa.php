<?php

// include 'check_session_oi.php';



?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>صفحة العميل</title>
    <link rel="stylesheet" href="add_clint.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Tajawal&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo&display=swap">
    <link rel="stylesheet" href="responsive.css">
    <style>
        .user-name {
            direction: rtl;
        }
        
        main{
            height: fit-content;
        }
        
        .first-name-group, .last-name-group {
    display: none;
}

input{
        width: 100%;
}
    </style>
</head>
<body>
<!-- main -->
<main>
    <!-- header -->
<?php include "header.php"; ?>


        <div class="titt">
        <h3>إضافة معاملة</h3>
        </div>
                
                <div class="left-sec">
            <div class="sign-up_container">
                <div class="real-sign-up_container">
<?php $client_id = $_GET['id']; ?>
                <form action="new_moa.php?id=<?php echo $client_id; ?>" method="post" id="passwordForm" class="content" enctype="multipart/form-data">
 
    <div class="form-group">
        <div class="input-group">
            <input type="number" name="total_amount" placeholder="المبلغ الإجمالي" id="total_amount" class="total_amount">
        </div>

        <!-- <div class="input-group">
            <input type="date" name="birth_date" id="birth_date" class="birth_date">
        </div> -->
    </div>

    <div class="form-group">
        <div class="input-group">
            <input type="number" placeholder="المؤخر" name="delay" id="delay" class="delay">
        </div>

        
        <div class="input-group">
            <input type="number" name="advance" placeholder="المُقدم" id="advance" class="advance">
        </div>
    </div>

    <div class="form-group">
        <div class="input-group">
            <input type="number" name="kest_value" placeholder="قيمة القسط" id="kest_value" class="kest_value">
        </div>

        <div class="input-group">
            <input type="date" name="first_pay_date" id="first_pay_date" class="first_pay_date">
        </div>
    </div>

    <div class="form-group">
        <div class="input-group">
            <input type="text" name="adition_notes" placeholder="ملاحظات إضافية" id="adition_notes" class="adition_notes">
        </div>

        <!-- <div class="input-group">
            <input type="date" name="birth_date" id="birth_date" class="birth_date">
        </div> -->
    </div>

    <div class="form-group">
        <div class="input-group">
            <input type="text" name="bank_name" placeholder="إسم البنك" id="bank_name" class="bank_name">
        </div>

        <!-- <div class="input-group">
            <input type="date" name="birth_date" id="birth_date" class="birth_date">
        </div> -->
    </div>
    
    




    <div class="form-group form-group-submit">
        <button type="submit" class="submit_data">إنشاء حساب</button>
    </div>
</form>




<script>
$(document).ready(function() {
    function formatState (state) {
        if (!state.id) {
            return state.text;
        }
        var baseUrl = state.element.dataset.image;
        var $state = $(
            '<span><img src="' + baseUrl + '" class="img-flag" style="width: 20px; margin-right: 10px;"/>' + state.text + '</span>'
        );
        return $state;
    };

    $('#bank_select').select2({
        templateResult: formatState,
        templateSelection: formatState
    });
});
</script>


<script>
    document.addEventListener("DOMContentLoaded", function() {
    const passwordInput = document.getElementById('user_password');
    const confirmPasswordInput = document.getElementById('confirm_user_password');
    const errorMessage = document.getElementById('error_message');

    function validatePasswords() {
        if (passwordInput.value !== confirmPasswordInput.value) {
            errorMessage.style.display = 'block'; // عرض رسالة الخطأ
        } else {
            errorMessage.style.display = 'none'; // إخفاء رسالة الخطأ
        }
    }

    // إضافة حدث عند كتابة المستخدم في حقول كلمة المرور
    passwordInput.addEventListener('input', validatePasswords);
    confirmPasswordInput.addEventListener('input', validatePasswords);
});

</script>



<script>
    const passwordForm = document.getElementById('passwordForm');
    const passwordInput = document.getElementById('user_password');
    const confirmPasswordInput = document.getElementById('confirm_user_password');
    const errorMessage = document.getElementById('error_message');

    passwordForm.addEventListener('submit', function(event) {
        // التحقق من مطابقة كلمتي السر
        if (passwordInput.value !== confirmPasswordInput.value) {
            event.preventDefault(); // منع الإرسال إذا كانت كلمتا السر غير متطابقتين
            errorMessage.style.display = 'flex'; // إظهار الرسالة
            passwordInput.value = ''; // تفريغ كلمة السر
            confirmPasswordInput.value = ''; // تفريغ تأكيد كلمة السر
            passwordInput.style.border = '1px solid red'; // تغيير لون الحدود للأحمر
            confirmPasswordInput.style.border = '1px solid red'; // تغيير لون الحدود للأحمر
            errorMessage.textContent = 'كلمتا السر غير متطابقتين';
        } else {
            errorMessage.style.display = 'none'; // إخفاء الرسالة إذا كان كل شيء صحيح
            passwordInput.style.border = ''; // إعادة الحدود الأصلية
            confirmPasswordInput.style.border = ''; // إعادة الحدود الأصلية
        }
    });
</script>

                    
                </div>
            </div>
        </div>


</main>

    <?php 
    include "aside.php";
    ?>
</body>
</html>
