<?php
include "db_connection.php";

// التحقق من وجود الـ id في الـ GET
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // تأمين الـ id ضد الهجمات (الحقن SQL)
    $id = $conn->real_escape_string($id);

    // استعلام SQL لجلب البيانات من جدول wakil
    $sql = "SELECT * FROM wakil WHERE id = '$id'";

    // تنفيذ الاستعلام
    $result = $conn->query($sql);

    // التحقق إذا كانت هناك بيانات مطابقة
    if ($result->num_rows > 0) {
        // جلب البيانات من السطر الأول
        $row = $result->fetch_assoc();
    } else {
        // إذا لم يتم العثور على بيانات
        die("لا توجد بيانات لهذا المعرف.");
    }
} else {
    // إذا لم يكن هناك id في الـ GET
    die("الـ id غير موجود.");
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>عرض بيانات الوكيل</title>
    <style>
        * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Arial', sans-serif;
    background-color: #f0f4f8;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.container {
    width: 100%;
    max-width: 400px;
    margin: 20px;
}

.user-card {
    background-color: white;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    text-align: center;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.user-card:hover {
    transform: scale(1.05);
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
}

.profile-img {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    object-fit: cover;
    margin-bottom: 15px;
}

.user-name {
    font-size: 24px;
    font-weight: bold;
    color: #333;
    margin-bottom: 10px;
}

.user-info {
    font-size: 16px;
    color: #555;
    margin-bottom: 8px;
}

.social-links {
    margin-top: 15px;
}

.social-link {
    text-decoration: none;
    color: #007bff;
    margin: 5px;
    font-size: 16px;
    transition: color 0.3s ease;
}

.social-link:hover {
    color: #0056b3;
}

.back-icon {
            position: fixed;
            top: 20px;
            left: 20px;
            font-size: 30px;
            color: #333;
            background-color: transparent;
            border: none;
            cursor: pointer;
        }

        .back-icon:hover {
            color: #4CAF50; /* تغيير اللون عند التمرير */
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>

<i class="fas fa-arrow-left back-icon" onclick="history.back()"></i>

    <div class="container">
        <div class="user-card">
            <h2 class="user-name"><?php echo htmlspecialchars($row['full_name']); ?></h2>
            <p class="user-info">البريد الإلكتروني: <?php echo htmlspecialchars($row['email']); ?></p>
            <p class="user-info">الهاتف: <?php echo htmlspecialchars($row['phone_number']); ?></p>
            <p class="user-info">العنوان: <?php echo htmlspecialchars($row['address']); ?></p>
            <p class="user-info">الوظيفة: <?php echo htmlspecialchars($row['job']); ?></p>
            <p class="user-info">الرقم القومي: <?php echo htmlspecialchars($row['national_id']); ?></p>
        </div>
    </div>
</body>
</html>

<?php
// إغلاق الاتصال بقاعدة البيانات
$conn->close();
?>
