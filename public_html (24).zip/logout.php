<?php
// بدء الجلسة
session_start();

// حذف الجلسة
session_unset();
session_destroy();

// إعادة توجيه المستخدم إلى صفحة إدخال كلمة السر
header("Location: index.php");
exit();
?>
