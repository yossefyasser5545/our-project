<?php
include "db_connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // استقبال البيانات من النموذج
    $full_name = $_POST['full_name'];
    $user_address = $_POST['user_address'];
    $user_email = $_POST['user_email'];
    $national_id = $_POST['national_id'];
    $phone_number = $_POST['phone_number'];
    $profession = $_POST['profession'];
    $client_id = $_POST['client_id'];

    // التأكد من وجود بيانات
    if (!empty($full_name) && !empty($user_address) && !empty($user_email) && !empty($national_id) && !empty($phone_number)) {
        // التحقق من صحة البريد الإلكتروني
        if (!filter_var($user_email, FILTER_VALIDATE_EMAIL)) {
            echo "البريد الإلكتروني غير صالح.";
        } else {
            // إدخال البيانات في جدول wakil باستخدام Prepared Statements
            $sql = "INSERT INTO wakil (full_name, address, email, national_id, phone_number, job, client_id) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);

            // ربط المعاملات
            $stmt->bind_param("sssssss", $full_name, $user_address, $user_email, $national_id, $phone_number, $profession, $client_id);

            // تنفيذ الاستعلام
            if ($stmt->execute()) {
                echo "تم إضافة البيانات بنجاح";
                header("location: success.html");
            } else {
                echo "خطأ في إضافة البيانات: " . $stmt->error;
            }

            // غلق الجملة
            $stmt->close();
        }
    } else {
        echo "يرجى ملء جميع الحقول المطلوبة.";
    }
}

$conn->close();
?>
