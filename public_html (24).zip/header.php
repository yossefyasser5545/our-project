        
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Tajawal&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Cairo&display=swap" rel="stylesheet">
    <title>أقساطك</title>
<link rel="icon" href="Images/Logos/People Dollar logo, Money Finances logo.png" type="image/png">



<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Tajawal&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Cairo&display=swap" rel="stylesheet">


<header>
    <div class="real-header">
        <!-- left -->
        <div class="left">
            <div onclick="confirmLogout()" class="first-sec">
                <i class="fas fa-sign-out-alt"></i>
            </div>

            <div class="second-sec">
                <a href="#" class="user-img">
                    <img src="Images/Logos/People Dollar logo, Money Finances logo (1).png" alt="" class="real-user-img">
                </a>

                <div class="user-name" style="direction: rtl;">
                    مرحباً                 </div>
            </div>

            <div class="threeth-sec">
                
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>أقساطك</title>
<link rel="icon" href="Images/Logos/People Dollar logo, Money Finances logo.png" type="image/png">
</head>


<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Tajawal&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Cairo&display=swap" rel="stylesheet">



                
                <!--<a style="text-decoration: none;" href="archive.php" class="icon-box">-->

                <!--    <i class="fas fa-archive"></i>-->
                <!--</a>-->
                
                <!--<a href="accepts.php" class="icon-box">-->

                <!--    <i class="fas fa-user-cog"></i>-->
                <!--</a>-->
                
                <!--<a style="text-decoration: none;" href="payments.php" class="icon-box">-->

                <!--    <i class="fas fa-money-bill"></i>-->
                <!--</a>-->


        
                <a onclick="addPopup()" id="notfication-icon" class="icon-box" style="cursor: pointer">
                    <i class="fas fa-bell"></i>
                </a>
            </div>
        </div>

        <!-- right -->
        <div class="right">
        </div>
        
        <div class="humberg icon humber_icon">
    <i class="fas fa-bars hamburger"></i>
    </div>
    </div>
</header>