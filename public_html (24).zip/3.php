<?php
include "db_connection.php";

if (isset($_GET['id'])) {
    $notification_id = $_GET['id'];
    
    // تحديث حالة الإشعار إلى مقروء
    $update_sql = "UPDATE notifications SET is_read = 1 WHERE id = $notification_id";
    $conn->query($update_sql);
    
    // إعادة توجيه المستخدم إلى صفحة الإشعارات
    header("Location: 2.php");
    exit();
}

$conn->close();
?>
