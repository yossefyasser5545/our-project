<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include "db_connection.php";

// تحقق من وجود معرّف العميل
if (isset($_POST['client_id'])) {
    $client_id = $_POST['client_id'];

    // تحقق إذا كان العميل موجودًا في قاعدة البيانات
    $check_client = "SELECT * FROM clients WHERE id = ?";
    $stmt = $conn->prepare($check_client);
    
    if ($stmt === false) {
        echo "حدث خطأ أثناء تحضير استعلام التحقق من العميل.";
        exit;
    }

    $stmt->bind_param("i", $client_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows == 0) {
        echo "العميل غير موجود في قاعدة البيانات.";
        $stmt->close();
        exit;
    }
    $stmt->close();

    // حذف السجلات المرتبطة في جدول sub_installments
    $delete_sub_installments = "DELETE FROM sub_installments WHERE client_id = ?";
    $stmt = $conn->prepare($delete_sub_installments);

    if ($stmt === false) {
        echo "حدث خطأ أثناء تحضير استعلام حذف السجلات من sub_installments.";
        exit;
    }

    $stmt->bind_param("i", $client_id);
    
    if ($stmt->execute()) {
        echo "تم حذف السجلات المرتبطة من sub_installments بنجاح. ";
    } else {
        echo "حدث خطأ أثناء حذف السجلات من sub_installments: " . $stmt->error;
    }
    $stmt->close();

    // حذف السجلات المرتبطة في جدول advances
    $delete_advances = "DELETE FROM advances WHERE client_id = ?";
    $stmt = $conn->prepare($delete_advances);

    if ($stmt === false) {
        echo "حدث خطأ أثناء تحضير استعلام حذف السجلات من advances.";
        exit;
    }

    $stmt->bind_param("i", $client_id);

    if ($stmt->execute()) {
        echo "تم حذف السجلات المرتبطة من advances بنجاح. ";
    } else {
        echo "حدث خطأ أثناء حذف السجلات من advances: " . $stmt->error;
    }
    $stmt->close();

    // حذف السجلات المرتبطة في جدول delays
    $delete_delays = "DELETE FROM delays WHERE client_id = ?";
    $stmt = $conn->prepare($delete_delays);

    if ($stmt === false) {
        echo "حدث خطأ أثناء تحضير استعلام حذف السجلات من delays.";
        exit;
    }

    $stmt->bind_param("i", $client_id);

    if ($stmt->execute()) {
        echo "تم حذف السجلات المرتبطة من delays بنجاح. ";
    } else {
        echo "حدث خطأ أثناء حذف السجلات من delays: " . $stmt->error;
    }
    $stmt->close();

    // حذف السجلات المرتبطة في جدول sub_installments
    $delete_sub_installments = "DELETE FROM sub_installments WHERE client_id = ?";
    $stmt = $conn->prepare($delete_sub_installments);

    if ($stmt === false) {
        echo "حدث خطأ أثناء تحضير استعلام حذف السجلات من sub_installments.";
        exit;
    }

    $stmt->bind_param("i", $client_id);
    
    if ($stmt->execute()) {
        echo "تم حذف السجلات المرتبطة من sub_installments بنجاح. ";
    } else {
        echo "حدث خطأ أثناء حذف السجلات من sub_installments: " . $stmt->error;
    }
    $stmt->close();

    // حذف الأقساط الخاصة بالعميل
    $delete_installments = "DELETE FROM installments WHERE client_id = ?";
    $stmt = $conn->prepare($delete_installments);

    if ($stmt === false) {
        echo "حدث خطأ أثناء تحضير استعلام حذف الأقساط.";
        exit;
    }

    $stmt->bind_param("i", $client_id);

    if ($stmt->execute()) {
        echo "تم حذف الأقساط بنجاح. ";
    } else {
        echo "حدث خطأ أثناء حذف الأقساط: " . $stmt->error;
    }
    $stmt->close();

    // حذف العميل من جدول العملاء
    $delete_client = "DELETE FROM clients WHERE id = ?";
    $stmt = $conn->prepare($delete_client);

    if ($stmt === false) {
        echo "حدث خطأ أثناء تحضير استعلام حذف العميل.";
        exit;
    }

    $stmt->bind_param("i", $client_id);

    if ($stmt->execute()) {
        echo "تم حذف العميل بنجاح.";
    } else {
        echo "حدث خطأ أثناء حذف العميل: " . $stmt->error;
    }
    $stmt->close();

} else {
    echo "لم يتم تحديد العميل.";
}
?>
