<?php
include "db_connection.php";

// الحصول على قيمة الفلتر أو تعيينه إلى 'unread' إذا لم يكن موجودًا
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'unread';

// استعلام للحصول على الإشعارات بناءً على الفلترة
if ($filter == 'unread') {
    $sql = "SELECT * FROM notifications WHERE is_read = 0 ORDER BY created_at DESC";
} elseif ($filter == 'read') {
    $sql = "SELECT * FROM notifications WHERE is_read = 1 ORDER BY created_at DESC";
} else {
    $sql = "SELECT * FROM notifications ORDER BY created_at DESC";
}

$result = $conn->query($sql);
?>

<style>
    /* تنسيق الـ select */
    .custom-select-wrapper {
        position: relative;
        display: inline-block;
        width: fit-content;
    }

    .custom-select {
        appearance: none;
        -webkit-appearance: none;
        -moz-appearance: none;
        background-color: #fff;
        border: 1px solid #ccc;
        border-radius: 8px;
        padding: 5px 14px;
        font-size: 13px;
        width: 143px;
        outline: none;
        cursor: pointer;
        transition: border-color 0.3s ease;
    }

    .custom-select:focus {
        border-color: #4CAF50;
    }

    .custom-select-wrapper::after {
        content: '\f0d7'; /* أيقونة FontAwesome للسهم */
        font-family: "Font Awesome 5 Free";
        font-weight: 900;
        position: absolute;
        left: 10px;
        top: 50%;
        transform: translateY(-50%);
        font-size: 18px;
        color: #777;
    }

    .custom-select:hover {
        border-color: #4CAF50;
        box-shadow: 0 0 8px rgba(0, 255, 0, 0.2);
    }

    .filter-container {
        margin-bottom: 20px;
        direction: rtl;
    }

    label {
        font-size: 18px;
        margin-bottom: 10px;
        display: block;
    }

    /* تنسيق الإشعارات */
    .notification-card {
        display: flex;
        align-items: flex-start;
        padding: 10px;
        margin-bottom: 10px;
        border-radius: 8px;
        background-color: #f9f9f9;
    }

    .notification-card.read {
        background-color: #e0e0e0;
    }

    .notification-card.unread {
        background-color: #fff3cd;
    }

    .notification-icon {
        font-size: 24px;
        margin-right: 10px;
    }

    .notification-content {
        flex-grow: 1;
    }

    .notification-title {
        font-weight: bold;
        margin: 0;
        padding-left: 27px;
    }

    .notification-description {
        font-size: 14px;
        color: #777;
    }

    .mark-read-btn {
        margin-left: 10px;
        padding: 5px 10px;
        background-color: #151542;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        width: 166px;
        height: 24px;
        font-size: 9px;
        position: relative;
        bottom: 0;
        transition: 0.2s;
    }

    .mark-read-btn:hover {
        background-color: #2a2a95;
    }
</style>

<div class="modal-content">
    <!-- تصفية الإشعارات -->
    <div class="filter-container">
        <form method="get" action="">
            <div class="custom-select-wrapper">
                <select name="filter" id="filter" class="custom-select" onchange="this.form.submit()">
                    <option value="unread" <?php echo $filter == 'unread' ? 'selected' : ''; ?>>غير مقروءة</option>
                    <option value="read" <?php echo $filter == 'read' ? 'selected' : ''; ?>>مقروءة</option>
                    <option value="all" <?php echo $filter == 'all' ? 'selected' : ''; ?>>الكل</option>
                </select>
            </div>
        </form>
    </div>

    <!-- الإشعارات -->
    <div id="notificationList">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="notification-card <?php echo $row['is_read'] ? 'read' : 'unread'; ?>" data-id="<?php echo $row['id']; ?>">
                <div class="notification-icon">ℹ️</div>
                <div class="notification-content">
                    <h4 class="notification-title"><?php echo htmlspecialchars($row['message']); ?></h4>
                    <p class="notification-description"><?php echo htmlspecialchars($row['cause']); ?></p>
                </div>
                <button class="mark-read-btn" onclick="markAsRead(<?php echo $row['id']; ?>)">تعيين كمقروء</button>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<script>
function markAsRead(notificationId) {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "mark_as_read.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onload = function() {
        if (xhr.status === 200) {
            var notificationCard = document.querySelector(`[data-id='${notificationId}']`);
            if (notificationCard) {
                notificationCard.classList.remove('unread');
                notificationCard.classList.add('read');
            } else {
                console.warn("Notification card not found!");
            }
        }
    };
    xhr.send("id=" + notificationId);
}
</script>

<?php
$conn->close();
?>
