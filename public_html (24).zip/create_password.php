<?php
include "db_connection.php";

// الحصول على البيانات من الطلب
$data = json_decode(file_get_contents("php://input"), true);
$password = $data['password'];

// التحقق من قوة كلمة السر (اختياري)
if (strlen($password) < 6) {
    echo json_encode(["message" => "كلمة السر يجب أن تكون أطول من 6 أحرف."]);
    exit;
}

// إدخال كلمة السر في قاعدة البيانات
$sql = "INSERT INTO passwords (password) VALUES ('$password')";
if ($conn->query($sql) === TRUE) {
    echo json_encode(["message" => "تم إنشاء كلمة السر بنجاح!"]);
} else {
    echo json_encode(["message" => "حدث خطأ أثناء إنشاء كلمة السر."]);
}
$conn->close();
