<?php
include "db_connection.php";

// الحصول على البيانات من الفورم
$payment_type = $_POST['payment_type'];
$operation = $_POST['operation'];
$class_id = intval($_POST['class_id']);

// تحديد القيم بناءً على العملية
$is_paid = ($operation === "دفع") ? 1 : 0;

if ($payment_type === "مقدم") {
    // تحديث جدول classes
    $query = "UPDATE advances SET is_paid = $is_paid WHERE id = $class_id";
} elseif ($payment_type === "مؤخر") {
    // تحديث جدول delays
    $query = "UPDATE delays SET is_paid = $is_paid WHERE id = $class_id";
} elseif ($payment_type === "قسط عادي") {
    // تحديث جدول sub_installments
    $query = "UPDATE sub_installments SET is_paid = $is_paid WHERE id = $class_id";
} else {
    die("نوع المدفوع غير صالح.");
}

// تنفيذ الاستعلام
if ($conn->query($query) === TRUE) {
    echo "تم تحديث البيانات بنجاح.";
} else {
    echo "حدث خطأ أثناء التحديث: " . $conn->error;
}

if (isset($_SERVER['HTTP_REFERER'])) {
    // إعادة التوجيه إلى الصفحة السابقة
    header("Location: " . $_SERVER['HTTP_REFERER']);
    exit; // تأكد من إنهاء السكربت بعد إعادة التوجيه
} else {
    // إذا لم تكن الصفحة السابقة معروفة، قم بتوجيه المستخدم إلى الصفحة الرئيسية أو أي صفحة أخرى
    header("Location: index.php");
    exit;
}

// إغلاق الاتصال
$conn->close();
?>
