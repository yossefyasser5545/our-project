<aside style="">
        
        <div class="real-aside">
                    <a href="index.php" class="option">
                        <img src="Images/Logos/People Dollar logo, Money Finances logo.png" alt="logo" class="logo">
                    </a>
                    <a href="clients.php" class="option">
                        <div class="option-icon2-g po2">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="option-text-g op2">العملاء</div>
                    </a>

                    <a href="settings.php" class="option">
                        <div class="option-icon2-g po9">
                        <i class="fas fa-cog"></i>
                        </div>
                        <div class="option-text-g op9">الإعدادات</div>
                    </a>
                </div>
        
        
                
        <style>
            @media (max-width: 500px){
            aside{
            /* display: block; */
        visibility: visible !important;
        position: fixed !important;
        top: 0;
        right: 0;
        width: 100%;
        height: 100%;
        z-index: 9999 !important;
        display: none;
        }
        }
        </style>
        <style>
            .logo{
        width: 163px;
            margin-bottom: -3em;
            margin-top: -2em;
            }
        </style>
        
               <script>
        document.querySelector('.humber_icon').addEventListener("click",function(){
            if (document.querySelector('aside').style.display === "block") {
                document.querySelector('aside').style.display = "none";
            }else{
                document.querySelector('aside').style.display = "block";
            }
            
        });
        </script>  
        
        
        
        
        <title>أقساطك</title>
        <link rel="icon" href="Images/Logos/People Dollar logo, Money Finances logo.png" type="image/png">    </aside>