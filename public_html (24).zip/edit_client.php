<?php
// الاتصال بقاعدة البيانات
include('db_connection.php');

// التحقق إذا كان الـ id موجوداً في الـ URL
if (isset($_GET['id'])) {
    $client_id = $_GET['id'];

    // استرجاع بيانات العميل من قاعدة البيانات
    $sql = "SELECT * FROM clients WHERE id = $client_id";
    $result = mysqli_query($conn, $sql);

    // التحقق إذا كانت البيانات موجودة
    if (mysqli_num_rows($result) > 0) {
        $client = mysqli_fetch_assoc($result);
    } else {
        echo "العميل غير موجود!";
        exit();
    }

    // استرجاع بيانات الأقساط الخاصة بالعميل
    $installments_sql = "SELECT * FROM installments WHERE client_id = $client_id";
    $installments_result = mysqli_query($conn, $installments_sql);
    $installments = mysqli_fetch_assoc($installments_result);

    // التحقق إذا تم إرسال التحديث
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // الحصول على القيم من النموذج
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $email = $_POST['email'];
        $phone_number = $_POST['phone_number'];
        $address = $_POST['address'];
        $image_path = $_POST['image_path'];
        $clint_code = $_POST['clint_code'];
        $national_id = $_POST['national_id'];
        $profession = $_POST['profession'];
        $birth_date = $_POST['birth_date'];
        $monthly_income = $_POST['monthly_income'];

        // تحديث بيانات العميل في قاعدة البيانات
        $update_sql = "UPDATE clients SET 
                        first_name = '$first_name', 
                        last_name = '$last_name', 
                        email = '$email', 
                        phone_number = '$phone_number', 
                        address = '$address', 
                        image_path = '$image_path', 
                        clint_code = '$clint_code', 
                        national_id = '$national_id', 
                        profession = '$profession', 
                        birth_date = '$birth_date', 
                        monthly_income = '$monthly_income' 
                       WHERE id = $client_id";

        if (mysqli_query($conn, $update_sql)) {
            echo "تم تحديث البيانات بنجاح!";
        } else {
            echo "حدث خطأ أثناء التحديث: " . mysqli_error($conn);
        }

        // تحديث بيانات الأقساط في قاعدة البيانات
        if (isset($_POST['total_amount'])) {
            $total_amount = $_POST['total_amount'];
            $kest_value = $_POST['kest_value'];
            $upfront = $_POST['upfront'];
            $deferred = $_POST['deferred'];
            $bank_name = $_POST['bank_name'];
            $additional_notes = $_POST['additional_notes'];

            $installment_update_sql = "UPDATE installments SET 
                                        total_amount = '$total_amount',
                                        kest_value = '$kest_value',
                                        upfront = '$upfront',
                                        deferred = '$deferred',
                                        bank_name = '$bank_name',
                                        additional_notes = '$additional_notes'
                                       WHERE client_id = $client_id";

            if (mysqli_query($conn, $installment_update_sql)) {
                echo "تم تحديث الأقساط بنجاح!";
                header("location: clients.php");
            } else {
                echo "حدث خطأ أثناء تحديث الأقساط: " . mysqli_error($conn);
            }
        }
    }
} else {
    echo "معرف العميل غير موجود في الـ URL.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>تعديل بيانات العميل</title>
    <style>
        /* إعادة ضبط عامة */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* إعدادات أساسية */
body {
  font-family: 'Poppins', sans-serif;
  line-height: 1.8;
  background: linear-gradient(135deg, #f3f8fc, #e3eaf0);
  color: #555;
  transition: all 0.3s ease-in-out;
}

/* الرأس (Header) */
header {
  background-color: #3a506b;
  color: #fff;
  padding: 20px;
  text-align: center;
  font-size: 1.8rem;
  font-weight: bold;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  border-bottom: 5px solid #ff6363;
}

/* القائمة الجانبية (Sidebar) */
.sidebar {
  width: 280px;
  background: #fdfdfd;
  color: #444;
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  padding: 40px 20px;
  box-shadow: 4px 0 10px rgba(0, 0, 0, 0.1);
  border-right: 1px solid #eee;
  overflow-y: auto;
}

.sidebar ul {
  list-style: none;
}

.sidebar ul li {
  margin: 15px 0;
  padding: 12px 15px;
  border-radius: 8px;
  font-size: 1.1rem;
  transition: background-color 0.3s ease, transform 0.2s ease;
}

.sidebar ul li:hover {
  background-color: #3a506b;
  color: #fff;
  transform: scale(1.05);
}

.sidebar ul li a {
  color: inherit;
  text-decoration: none;
  display: block;
  transition: color 0.3s ease;
}

.sidebar ul li a:hover {
  color: #ff6363;
}

/* المحتوى الرئيسي (Main Content) */
.main-content {
  margin-left: 300px;
  padding: 40px;
  background: rgba(255, 255, 255, 0.8);
  border-radius: 12px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  min-height: 100vh;
  backdrop-filter: blur(10px);
}

.main-content h1 {
  margin-bottom: 20px;
  font-size: 2.5rem;
  color: #3a506b;
}

.main-content p {
  margin-bottom: 20px;
  line-height: 1.6;
  color: #666;
}

/* الأزرار */
button {
  background-color: #3a506b;
  color: #fff;
  border: none;
  padding: 12px 20px;
  font-size: 1rem;
  border-radius: 8px;
  cursor: pointer;
  transition: transform 0.3s ease, background-color 0.3s ease;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

button:hover {
  background-color: #ff6363;
  transform: scale(1.1);
}

/* تأثيرات عامة */
.sidebar ul li,
button {
  animation: fadeIn 0.6s ease-in-out;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* تحسين الشاشة الصغيرة */
@media (max-width: 768px) {
  .sidebar {
    width: 100%;
    height: auto;
    position: relative;
  }

  .main-content {
    margin-left: 0;
    padding: 20px;
  }
}

/* تصميم شامل للنموذج */
form {
  background: #ffffff;
  padding: 30px;
  border-radius: 12px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  max-width: 500px;
  margin: 20px auto;
  font-family: 'Poppins', sans-serif;
}

/* تنسيق العناوين داخل الفورم */
form h2 {
  font-size: 1.8rem;
  margin-bottom: 20px;
  color: #3a506b;
  text-align: center;
}

/* تنسيق الحقول */
form .form-group {
  margin-bottom: 20px;
}

form label {
  display: block;
  margin-bottom: 8px;
  font-size: 1rem;
  color: #555;
  font-weight: 600;
}

/* حقول الإدخال */
form input[type="text"],
form input[type="email"],
form input[type="password"],
form input[type="number"],
form input[type="date"],
form textarea,
form select {
  width: 100%;
  padding: 12px 15px;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 1rem;
  color: #333;
  background: #f9f9f9;
  outline: none;
  transition: border-color 0.3s, box-shadow 0.3s;
}

form input:focus,
form textarea:focus,
form select:focus {
  border-color: #3a506b;
  box-shadow: 0 0 8px rgba(58, 80, 107, 0.2);
}

/* حقل النصوص الطويلة */
form textarea {
  height: 120px;
  resize: none;
}

/* أزرار الإرسال */
form button {
  width: 100%;
  padding: 12px 15px;
  font-size: 1rem;
  font-weight: bold;
  color: #fff;
  background-color: #3a506b;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: background-color 0.3s, transform 0.2s;
}

form button:hover {
  background-color: #ff6363;
  transform: scale(1.05);
}

/* رسائل الخطأ أو الملاحظات */
form .form-error {
  color: #ff6363;
  font-size: 0.9rem;
  margin-top: 5px;
}

form .form-success {
  color: #28a745;
  font-size: 0.9rem;
  margin-top: 5px;
}

    </style>
</head>
<body>
    <h1 style="text-align: center;">تعديل بيانات العميل</h1>
    
    <!-- نموذج تعديل بيانات العميل -->
    <form action="edit_client.php?id=<?php echo $client['id']; ?>" method="POST">
        <label for="first_name">الاسم الأول:</label>
        <input type="text" name="first_name" value="<?php echo $client['first_name']; ?>" required><br><br>

        <label for="last_name">الاسم الأخير:</label>
        <input type="text" name="last_name" value="<?php echo $client['last_name']; ?>" required><br><br>

        <label for="email">البريد الإلكتروني:</label>
        <input type="email" name="email" value="<?php echo $client['email']; ?>" required><br><br>

        <label for="phone_number">رقم الهاتف:</label>
        <input type="text" name="phone_number" value="<?php echo $client['phone_number']; ?>" required><br><br>

        <label for="address">العنوان:</label>
        <textarea name="address" required><?php echo $client['address']; ?></textarea><br><br>

        <label for="image_path">مسار الصورة:</label>
        <input type="text" name="image_path" value="<?php echo $client['image_path']; ?>"><br><br>

        <label for="clint_code">كود العميل:</label>
        <input type="text" name="clint_code" value="<?php echo $client['clint_code']; ?>" required><br><br>

        <label for="national_id">رقم الهوية:</label>
        <input type="text" name="national_id" value="<?php echo $client['national_id']; ?>" required><br><br>

        <label for="profession">المهنة:</label>
        <input type="text" name="profession" value="<?php echo $client['profession']; ?>"><br><br>

        <label for="birth_date">تاريخ الميلاد:</label>
        <input type="date" name="birth_date" value="<?php echo $client['birth_date']; ?>"><br><br>

        <label for="monthly_income">الدخل الشهري:</label>
        <input type="number" step="0.01" name="monthly_income" value="<?php echo $client['monthly_income']; ?>"><br><br>

        <h2>تعديل الأقساط</h2>

        <!-- نموذج تعديل بيانات الأقساط -->
        <label for="total_amount">المبلغ الإجمالي:</label>
        <input type="number" step="0.01" name="total_amount" value="<?php echo $installments['total_amount']; ?>" required><br><br>

        <label for="kest_value">قيمة القسط:</label>
        <input type="number" step="0.01" name="kest_value" value="<?php echo $installments['kest_value']; ?>" required><br><br>

        <label for="upfront">المقدم:</label>
        <input type="number" step="0.01" name="upfront" value="<?php echo $installments['upfront']; ?>"><br><br>

        <label for="deferred">المؤجل:</label>
        <input type="number" step="0.01" name="deferred" value="<?php echo $installments['deferred']; ?>"><br><br>

        <label for="bank_name">اسم البنك:</label>
        <input type="text" name="bank_name" value="<?php echo $installments['bank_name']; ?>"><br><br>

        <label for="additional_notes">ملاحظات إضافية:</label>
        <textarea name="additional_notes"><?php echo $installments['additional_notes']; ?></textarea><br><br>

        <button type="submit">تحديث البيانات</button>
    </form>
    
    <!-- <a href="client_list.php">رجوع إلى قائمة العملاء</a> -->
</body>
</html>
