<?php include "settings_logined.php" ?>
<?php
include "db_connection.php";

// 2. استلام الـ ID من الرابط عبر GET
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // 3. التحقق من أن الـ ID هو رقم
    if (is_numeric($id)) {
        // 4. جلب البيانات من جدول passwords باستخدام الـ ID
        $sql = "SELECT * FROM passwords WHERE id = $id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $current_password = $row['password']; // قيمة الـ password الحالية
        } else {
            echo "No record found with the given ID";
            exit;
        }

        // 5. التحقق إذا تم إرسال النموذج لتحديث الـ password
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $new_password = $_POST['password'];

            // التحقق من صحة كلمة المرور (مثلاً أن تكون أطول من 6 أحرف)
            if (strlen($new_password) >= 6) {
                // 6. استعلام التحديث
                $update_sql = "UPDATE passwords SET password = '$new_password' WHERE id = $id";
                
                if ($conn->query($update_sql) === TRUE) {
                    echo "Password updated successfully";
                    header("location: settings.php");
                } else {
                    echo "Error updating password: " . $conn->error;
                }
            } else {
                echo "Password must be at least 6 characters long";
            }
        }
    } else {
        echo "Invalid ID";
    }
} else {
    echo "ID not provided";
}

// 7. غلق الاتصال بقاعدة البيانات
$conn->close();
?>

<style>
    /* تنسيق عام للصفحة */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f4; /* خلفية هادئة */
    color: #333; /* لون نص هادئ */
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

/* تنسيق الحاوية الرئيسية */
.container {
    background-color: #fff; /* خلفية بيضاء للنموذج */
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* تأثير ظل خفيف */
    padding: 20px;
    width: 100%;
    max-width: 400px;
    box-sizing: border-box;
}

/* تنسيق العنوان */
h2 {
    text-align: center;
    color: #5e5e5e; /* لون هادئ للعناوين */
    margin-bottom: 20px;
    font-size: 24px;
}

/* تنسيق النموذج */
form {
    display: flex;
    flex-direction: column;
}

/* تنسيق الحقول */
label {
    font-size: 16px;
    margin-bottom: 8px;
    color: #666;
}

input[type="password"] {
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
    outline: none;
    transition: border-color 0.3s ease;
}

input[type="password"]:focus {
    border-color: #6c7ae0; /* تغيير لون الحدود عند التركيز */
}

/* تنسيق زر التحديث */
input[type="submit"] {
    padding: 12px;
    background-color: #6c7ae0; /* لون الزر */
    color: white;
    font-size: 16px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

input[type="submit"]:hover {
    background-color: #5a66c1; /* تغيير اللون عند التمرير */
}

/* تنسيق الرسائل */
.message {
    text-align: center;
    font-size: 16px;
    margin-top: 20px;
    color: #4caf50; /* اللون الأخضر للرسائل الناجحة */
}

.error {
    color: #e74c3c; /* اللون الأحمر للرسائل الخطأ */
}

</style>
<!-- 8. عرض النموذج لتعديل الـ password -->
<form method="POST" action="">
    <label for="password">New Password:</label>
    <input type="password" name="password" id="password" required>
    <input type="submit" value="Update Password">
</form>
