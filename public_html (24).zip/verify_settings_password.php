<?php
include "db_connection.php"; // تضمين اتصال قاعدة البيانات

// بدء الجلسة
session_start();

// التحقق من وجود كلمة السر في الجدول
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $password_input = $_POST['password'];

    // إعداد الاستعلام للتحقق من كلمة السر في قاعدة البيانات
    $sql = "SELECT * FROM settings_passwords WHERE password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $password_input);
    $stmt->execute();
    $result = $stmt->get_result();

    // التحقق إذا كانت كلمة السر موجودة
    if ($result->num_rows > 0) {
        // كلمة السر موجودة، نقوم بإنشاء الجلسة
        $_SESSION['settings_password_verified'] = true; // تخزين الجلسة للإشارة إلى أن كلمة السر تم التحقق منها

        // تحويل المستخدم إلى صفحة أخرى بعد التحقق بنجاح (مثال: صفحة النجاح)
        header("Location: settings.php");
        exit();
    } else {
        // كلمة السر غير موجودة
        echo "كلمة السر غير صحيحة!";
        // يمكنك إضافة إعادة توجيه في حالة عدم مطابقة كلمة السر
        // header("Location: index.php?error=true");
        exit();
    }
}

$conn->close(); // إغلاق الاتصال
?>
