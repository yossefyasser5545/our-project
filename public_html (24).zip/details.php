<?php include "logined.php" ?>
<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>صفحة العميل</title>
    <link rel="stylesheet" href="eksat_pays.css">
    <link rel="stylesheet" href="responsive.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Tajawal&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo&display=swap">
    <link rel="stylesheet" href="details.css">
</head>

<body>
    <!-- main -->
    <main>
        <!-- header -->
        <header>
            <div class="real-header" style="flex-direction: row;">
                <a href="clients.php" class="left">
                    <div class="first-sec">
                        <i class="fas fa-arrow-left"></i>
                    </div>
                </a>

                <div class="right">
                    <a style="color: #174239; font-weight: 600;" href="index.php">الصفحة الرئيسية</a>

                    <a href="#" class="logo">
                        <div class="real-logo">
                            <img src="Images/Logos/People Dollar logo, Money Finances logo (1).png" alt="Logo" class="logo">
                        </div>
                    </a>
                </div>
            </div>
        </header>
        <?php
        include "db_connection.php"; 

        if (isset($_GET['client_id'])) {
            $client_id = intval($_GET['client_id']); // تحويل القيمة إلى رقم صحيح للتأكد من الأمان

            // استعلام لاسترجاع بيانات العميل
            $query = "SELECT * FROM clients WHERE id = $client_id";
            $result = $conn->query($query);

            if ($result->num_rows > 0) {
                $client = $result->fetch_assoc();
        ?>
        <div class="row">
        <section class="main-eksat-data">
                <div class="row" style="flex-direction: row-reverse; justify-content: space-between; padding-inline: 1em;"><?php $user_id = $client['id']; ?>
                <button onclick='window.location.href="add_moa.php?id=<?php echo $user_id ; ?>"' class='view-reports-btn'>+ إضافة معاملة</button>
                <button onclick='window.location.href="add_wakil.php?id=<?php echo $user_id ; ?>"' class='view-reports-btn'>+ إضافة وكيل</button>
            <div class="clint-code">
                <div class="tittto">كود العميل: </div>
                <div class="real-clint-code"><?php echo htmlspecialchars($client['clint_code']); ?></div>
            </div>
                </div>

            <div class="clint-eksat">
                <div class="boxes left-information">
                    <div class="titt" style="display: flex; flex-direction: column; padding: 0; margin: 0; width: fit-content;">

                    <?php 
                    $query = "SELECT * FROM installments WHERE client_id = $client_id";
                    $result = $conn->query($query);

                    if ($result->num_rows > 0) {
                        while ($installment = $result->fetch_assoc()) {
                    ?>
                    <div class='card'>
                        <div class='box tit_box' style='width: 285px;'>
                            <div class='real-box'>
                                <div class='user_info'>قرض رقم <?php echo htmlspecialchars($installment['id']); ?></div>
                            </div>
                        </div>
                    </div>

                    <?php
                        // استعلام لاسترجاع الأقساط الفرعية المرتبطة بهذا القسط
                        $sub_query = "SELECT * FROM sub_installments WHERE installment_id = " . intval($installment['id']);
                        $sub_result = $conn->query($sub_query);

                        if ($sub_result->num_rows > 0) {
                    ?>
                    <div class='box' style='width: 50em; display: flex; flex-direction: row-reverse; align-items: center; gap: 1em; background: transparent;'>
                        <table style='border-collapse: collapse; width: 100%; text-align:center; font-family: Arial, sans-serif;'>
                            <tr style='background-color: #162142; color: white;'>
                                <th style='border: 1px solid #dddddd; padding: 8px;'>رقم القسط</th>
                                <th style='border: 1px solid #dddddd; padding: 8px;'>قيمة القسط</th>
                                <th style='border: 1px solid #dddddd; padding: 8px;'>تاريخ القسط</th>
                                <th style='border: 1px solid #dddddd; padding: 8px;'>حالة الدفع</th>
                            </tr>

                            <?php
                            $sql_presenter = "SELECT * FROM advances WHERE installment_id = " . intval($installment['id']);
                            $result_presenter = $conn->query($sql_presenter);

                            $sql_later = "SELECT * FROM delays WHERE installment_id = " . intval($installment['id']);
                            $result_later = $conn->query($sql_later);

                            if ($result_presenter->num_rows > 0) {
                                while($row = $result_presenter->fetch_assoc()) {
                            ?>
                            <tr style='background-color: #e5f7f1;'>
                                <td style='border: 1px solid #dddddd; padding: 8px;'>المُقدم</td>
                                <td style='border: 1px solid #dddddd; padding: 8px;'><?php echo $row['advance_value']; ?> ريال</td>
                                <td style='border: 1px solid #dddddd; padding: 8px;'><?php echo $row['advance_date']; ?></td>
                                <?php

if ($row['is_paid'] == 1) {
?>

<td style='border: 1px solid #dddddd; padding: 8px;'>
<form action="process_payment.php" method="POST">
<input type="hidden" name="class_id" value="<?php echo $row['id']; ?>" readonly>
<input type="hidden" name="payment_type" value="مقدم" readonly>
<input type="hidden" name="operation" value="إلغاء الدفع" readonly>
<input type="submit" value="إلغاء الدفع" style="background-color: #b00500; color: white; padding: 5px 10px; border: none; border-radius: 5px;" />
</form>
</td>

<?php
} else {
    // تنفيذ حدث آخر إذا لم تكن القيمة تساوي 1
?>

<td style='border: 1px solid #dddddd; padding: 8px;'>
<form action="process_payment.php" method="POST">
<input type="hidden" name="class_id" value="<?php echo $row['id']; ?>" readonly>
<input type="hidden" name="payment_type" value="مقدم" readonly>
<input type="hidden" name="operation"  value="دفع" readonly>
<input type="submit" value="دفع" style="background-color: #00b050; color: white; padding: 5px 10px; border: none; border-radius: 5px;" />
</form>
</td>

                                <?php
}

 ?>
                            </tr>
                            <?php
                                }
                            } else {
                                // echo "<p>لا توجد نتائج للمُقدّم.</p>";
                            }
                            $i = 1;
                            while ($sub_installment = $sub_result->fetch_assoc()) {
                            ?>
                            <tr style='background-color: #e5f7f1;'>
                                <td style='border: 1px solid #dddddd; padding: 8px;'><?php echo $i; ?></td>
                                <td style='border: 1px solid #dddddd; padding: 8px;'><?php echo $sub_installment['installment_value']; ?> ريال</td>
                                <td style='border: 1px solid #dddddd; padding: 8px;'><?php echo $sub_installment['sub_installment_date']; ?></td>
                                <?php

if ($sub_installment['is_paid'] == 1) {
?>

<td style='border: 1px solid #dddddd; padding: 8px;'>
<form action="process_payment.php" method="POST">
<input type="hidden" name="class_id" value="<?php echo $sub_installment['id']; ?>" readonly>
<input type="hidden" name="payment_type" value="قسط عادي" readonly>
<input type="hidden" name="operation" value="إلغاء الدفع" readonly>
<input type="submit" value="إلغاء الدفع" style="background-color: #b00500; color: white; padding: 5px 10px; border: none; border-radius: 5px;" />
</form>
</td>

<?php
} else {
    // تنفيذ حدث آخر إذا لم تكن القيمة تساوي 1
?>

<td style='border: 1px solid #dddddd; padding: 8px;'>
<form action="process_payment.php" method="POST">
<input type="hidden" name="class_id" value="<?php echo $sub_installment['id']; ?>" readonly>
<input type="hidden" name="payment_type" value="قسط عادي" readonly>
<input type="hidden" name="operation"  value="دفع" readonly>
<input type="submit" value="دفع" style="background-color: #00b050; color: white; padding: 5px 10px; border: none; border-radius: 5px;" />
</form>
</td>

                                <?php
}

 ?>
                            </tr>
                            <?php
                                $i++;
                            }

                            if ($result_later->num_rows > 0) {
                                while($row = $result_later->fetch_assoc()) {
                            ?>
                            <tr style='background-color: #e5f7f1;'>
                                <td style='border: 1px solid #dddddd; padding: 8px;'>المؤخر</td>
                                <td style='border: 1px solid #dddddd; padding: 8px;'><?php echo $row['delay_value']; ?> ريال</td>
                                <td style='border: 1px solid #dddddd; padding: 8px;'><?php echo $row['delay_date']; ?></td>

                                <?php

if ($row['is_paid'] == 1) {
?>

<td style='border: 1px solid #dddddd; padding: 8px;'>
<form action="process_payment.php" method="POST">
<input type="hidden" name="class_id" value="<?php echo $row['id']; ?>" readonly>
<input type="hidden" name="payment_type" value="مؤخر" readonly>
<input type="hidden" name="operation" value="إلغاء الدفع" readonly>
<input type="submit" value="إلغاء الدفع" style="background-color: #b00500; color: white; padding: 5px 10px; border: none; border-radius: 5px;" />
</form>
</td>

<?php
} else {
    // تنفيذ حدث آخر إذا لم تكن القيمة تساوي 1
?>

<td style='border: 1px solid #dddddd; padding: 8px;'>
<form action="process_payment.php" method="POST">
<input type="hidden" name="class_id" value="<?php echo $row['id']; ?>" readonly>
<input type="hidden" name="payment_type" value="مؤخر" readonly>
<input type="hidden" name="operation"  value="دفع" readonly>
<input type="submit" value="دفع" style="background-color: #00b050; color: white; padding: 5px 10px; border: none; border-radius: 5px;" />
</form>
</td>

                                <?php
}

 ?>
<!-- //                                 <td style='border: 1px solid #dddddd; padding: 8px;'>
//                                     <form action="cansel_advance_payment.php" method="post">
//                                         <input type="hidden" name="installment_id" value="<?php echo $row['id']; ?>" />
//                                         <input type="submit" value="إلغاء الدفع" style="background-color: #b00500; color: white; padding: 5px 10px; border: none; border-radius: 5px;" />
//                                     </form>
//                                 </td> -->
                            </tr>
                            <?php
                                }
                            } else {
                                // echo "<p>لا توجد نتائج للمؤخر.</p>";
                            }
                            ?>

                        </table>
                    </div>
                    <?php
                        } else {
                            // echo "<p>لا توجد أقساط فرعية لهذا القسط.</p>";
                        }
                    } ?>
</table>
</div>
</div>
<?php
        } else {
            // echo "<p>لا توجد أقساط مسجلة لهذا العميل.</p>";
        }
    }
}
?>
</div> 
</section>
<?php

?>

                <div class="boxes right-information">

                    <div class="box" style="width: 26em !important;">
                        <div class="head">المعلومات الشخصية</div>
                        <div class="content">
                            <div class="data">
                                <div class="reoww">
                                    <div class="img-container">
                                        <img src="uploads/user_imgs/<?php echo htmlspecialchars($client['image_path']); ?>" alt="" class="user-img">
                                    </div>

                                    <div class="ext_data">
                                        <div class="name-container">
                                        <?php echo htmlspecialchars($client['first_name']); ?> <?php echo htmlspecialchars($client['last_name']); ?>
                                     </div>
                                        <div class="nationality_number-container">
                                        <?php echo htmlspecialchars($client['national_id']); ?> </div>
                                    </div>
                                </div>

                                <div class="reow">
                                    <div class="titto">البريد الإلكتروني</div>
                                    <div class="value"></div>
                                </div>

                                <div class="reow">
                                    <div class="titto">الوكلاء</div>
                                    <div class="value"><?php
                                    
                                    $sql = "SELECT * FROM wakil WHERE client_id = ?";
                                    $stmt = $conn->prepare($sql);
                                    $stmt->bind_param("i", $client['id']); // "i" تعني أن المعامل هو نوع بيانات صحيح (integer)
                                    $stmt->execute();
                                    $result = $stmt->get_result();
                                    
                                    // echo "<h1>قائمة الوكلاء</h1>";
                                    
                                    if ($result->num_rows > 0) {
                                        echo "<ul>";
                                        while ($row = $result->fetch_assoc()) {
                                            // عرض اسم الوكيل مع رابط لصفحة تفاصيل الوكيل
                                            echo "<li><a href='agent_details.php?id=" . $row['id'] . "'>" . $row['full_name'] . "</a></li>";
                                        }
                                        echo "</ul>";
                                    } else {
                                        echo "لا يوجد وكلاء لعرضهم.";
                                    }
                                    
                                    ?></div>
                                </div>

                                <div class="reow">
                                    <div class="titto">رقم الهاتف</div>
                                    <div class="value"><?php echo htmlspecialchars($client['phone_number']); ?></div>
                                </div>
                                <div class="reow">
                                    <div class="titto">تاريخ الميلاد</div>
                                    <div class="value"><?php echo htmlspecialchars($client['birth_date']); ?></div>
                                </div>
                                <div class="reow" style="display: flex;
    justify-content: flex-end;
    flex-direction: row;
    flex-wrap: wrap;
    gap: 14px;">
                                    <a style="width: fit-content;
    position: relative;
    bottom: 0;
    left: 0;" class="edit-action" href="edit_client.php?id=<?php echo $user_id ; ?>">
                                        <i style="color: #151542;" class="fas fa-edit"></i>
                                    </a>

                                    <a style="width: fit-content; position: relative; bottom: 0; left: 0;" class="delete-action" onclick="deleteClient(<?php echo $client['id']; ?>)">
                                        <i style="color: #f00;" class="fas fa-trash-alt"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <script>
    function deleteClient(clientId) {
        if (confirm("هل أنت متأكد من أنك تريد حذف هذا العميل؟")) {
            // إرسال الطلب إلى الخادم باستخدام AJAX
            const xhr = new XMLHttpRequest();
            xhr.open("POST", "delete_client.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

            // إرسال id العميل
            xhr.send("client_id=" + clientId);

            // بعد انتهاء العملية
            xhr.onload = function () {
                if (xhr.status === 200) {
                    alert("تم حذف العميل بنجاح.");
                    window.history.back();
                    // إزالة العميل من الجدول دون إعادة تحميل الصفحة
                    const row = document.querySelector('tr[data-user-id="' + clientId + '"]');
                    if (row) row.remove();
                    const installmentsRow = document.querySelector('#installments-' + clientId);
                    if (installmentsRow) installmentsRow.remove();
                } else {
                    alert("حدث خطأ أثناء الحذف.");
                }
            };
        }
    }
</script>


                </div>


        </section>
    </main>
</body>

</html>

<?php 

                                    


// إغلاق الاتصال
$conn->close();
?> 
