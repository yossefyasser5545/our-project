<?php
include "db_connection.php";

// استعلام للحصول على الأقساط المتأخرة من جدول sub_installments
$sql = "SELECT * FROM sub_installments WHERE sub_installment_date < NOW() AND is_paid = 0";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $installment_id = $row['installment_id'];  // تم تصحيح التكرار هنا
        $client_id = $row['client_id'];
        $sub_inst_date = $row['sub_installment_date'];
        
        // استعلام للحصول على تفاصيل العميل (مثل الكود أو الاسم)
        $customer_sql = "SELECT clint_code FROM clients WHERE id = '$client_id'";
        $customer_result = $conn->query($customer_sql);
        
        if ($customer_result->num_rows > 0) {
            $customer = $customer_result->fetch_assoc();
            $customer_code = $customer['clint_code'];

            // استعلام للحصول على تفاصيل القرض من جدول installments
            $loan_sql = "SELECT id FROM installments WHERE id = '$installment_id'";
            $loan_result = $conn->query($loan_sql);

            if ($loan_result->num_rows > 0) {
                $loan = $loan_result->fetch_assoc();
                $loan_number = $loan['id'];
                
                // تحديد سبب الإشعار
                $cause = "قسط " . $sub_inst_date . " رقم " . $installment_id . " لم يتم دفعه حتى الآن";

                // التحقق من وجود إشعار بنفس السبب
                $check_sql = "SELECT * FROM notifications WHERE cause = '$cause'";
                $check_result = $conn->query($check_sql);
                
                // إذا لم يوجد إشعار بنفس السبب، قم بإضافة الإشعار
                if ($check_result->num_rows == 0) {
                    $notification_message = "لقد قام العميل صاحب الكود " . $customer_code . " بالتأخير في دفع قسط " . $sub_inst_date . " الخاص بالقرض رقم " . $loan_number;
                    $insert_sql = "INSERT INTO notifications (message, cause, type) VALUES ('$notification_message', '$cause', 'delayed')";
                    $conn->query($insert_sql);
                }
            }
        }
    }
}

// استعلام للحصول على الأقساط المؤجلة من جدول delays
$delays_sql = "SELECT * FROM delays WHERE delay_date < NOW() AND is_paid = 0";
$delays_result = $conn->query($delays_sql);

if ($delays_result->num_rows > 0) {
    while ($row = $delays_result->fetch_assoc()) {
        $delay_id = $row['id'];
        $client_id = $row['client_id'];
        $delay_date = $row['delay_date'];
        
        // استعلام للحصول على تفاصيل العميل (مثل الكود أو الاسم)
        $customer_sql = "SELECT clint_code FROM clients WHERE id = '$client_id'";
        $customer_result = $conn->query($customer_sql);
        
        if ($customer_result->num_rows > 0) {
            $customer = $customer_result->fetch_assoc();
            $customer_code = $customer['clint_code'];

            // استعلام للحصول على تفاصيل القرض من جدول delays
            $delay_sql = "SELECT id FROM delays WHERE id = '$delay_id'";
            $delay_result = $conn->query($delay_sql);

            if ($delay_result->num_rows > 0) {
                $delay = $delay_result->fetch_assoc();
                $delay_number = $delay['id'];
                
                // تحديد سبب الإشعار
                $cause = "قسط مؤجل " . $delay_date . " رقم " . $delay_id . " لم يتم دفعه حتى الآن";

                // التحقق من وجود إشعار بنفس السبب
                $check_sql = "SELECT * FROM notifications WHERE cause = '$cause'";
                $check_result = $conn->query($check_sql);
                
                // إذا لم يوجد إشعار بنفس السبب، قم بإضافة الإشعار
                if ($check_result->num_rows == 0) {
                    $notification_message = "لقد قام العميل صاحب الكود " . $customer_code . " بالتأخير في دفع القسط المؤجل " . $delay_date . " الخاص بالقرض رقم " . $delay_number;
                    $insert_sql = "INSERT INTO notifications (message, cause, type) VALUES ('$notification_message', '$cause', 'delayed')";
                    $conn->query($insert_sql);
                }
            }
        }
    }
}

// استعلام للحصول على الأقساط المُقدمة من جدول advances
$advances_sql = "SELECT * FROM advances WHERE advance_date < NOW() AND is_paid = 0";
$advances_result = $conn->query($advances_sql);

if ($advances_result->num_rows > 0) {
    while ($row = $advances_result->fetch_assoc()) {
        $advance_id = $row['id'];
        $client_id = $row['client_id'];
        $advance_date = $row['advance_date'];
        
        // استعلام للحصول على تفاصيل العميل (مثل الكود أو الاسم)
        $customer_sql = "SELECT clint_code FROM clients WHERE id = '$client_id'";
        $customer_result = $conn->query($customer_sql);
        
        if ($customer_result->num_rows > 0) {
            $customer = $customer_result->fetch_assoc();
            $customer_code = $customer['clint_code'];

            // استعلام للحصول على تفاصيل القرض من جدول advances
            $advance_sql = "SELECT id FROM advances WHERE id = '$advance_id'";
            $advance_result = $conn->query($advance_sql);

            if ($advance_result->num_rows > 0) {
                $advance = $advance_result->fetch_assoc();
                $advance_number = $advance['id'];
                
                // تحديد سبب الإشعار
                $cause = "قسط مُقدم " . $advance_date . " رقم " . $advance_id . " لم يتم دفعه حتى الآن";

                // التحقق من وجود إشعار بنفس السبب
                $check_sql = "SELECT * FROM notifications WHERE cause = '$cause'";
                $check_result = $conn->query($check_sql);
                
                // إذا لم يوجد إشعار بنفس السبب، قم بإضافة الإشعار
                if ($check_result->num_rows == 0) {
                    $notification_message = "لقد قام العميل صاحب الكود " . $customer_code . " بالتأخير في دفع القسط المُقدم " . $advance_date . " الخاص بالقرض رقم " . $advance_number;
                    $insert_sql = "INSERT INTO notifications (message, cause, type) VALUES ('$notification_message', '$cause', 'advance')";
                    $conn->query($insert_sql);
                }
            }
        }
    }
}

$conn->close();
?>
