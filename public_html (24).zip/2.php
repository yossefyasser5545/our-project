<?php
include "db_connection.php";

// تحديد حالة الفلترة (مقروءة، غير مقروءة، الكل)
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'unread';

// استعلام للحصول على الإشعارات بناءً على الفلترة
if ($filter == 'unread') {
    $sql = "SELECT * FROM notifications WHERE is_read = 0 ORDER BY created_at DESC";
} elseif ($filter == 'read') {
    $sql = "SELECT * FROM notifications WHERE is_read = 1 ORDER BY created_at DESC";
} else {
    $sql = "SELECT * FROM notifications ORDER BY created_at DESC";
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>الإشعارات</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> <!-- Font Awesome -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f7fc;
            color: #333;
            margin: 0;
            padding: 0;
        }

        /* نافذة منبثقة */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.6);
        }

        .modal-content {
            background-color: #fff;
            margin: 10% auto;
            padding: 20px;
            border-radius: 10px;
            width: 80%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            animation: fadeIn 0.5s ease-in-out;
        }

        .close {
            color: #aaa;
            font-size: 30px;
            font-weight: bold;
            cursor: pointer;
            position: absolute;
            top: 10px;
            right: 20px;
        }

        .close:hover {
            color: #000;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        /* تنسيق زر عرض الإشعارات */
        #openModalBtn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 15px 25px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        #openModalBtn:hover {
            background-color: #45a049;
        }

        /* تنسيق البطاقات */
        .notification-card {
            display: flex;
            align-items: center;
            padding: 15px;
            margin: 10px 0;
            border-radius: 8px;
            background-color: #f9f9f9;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, background-color 0.3s ease;
        }

        .notification-card:hover {
            transform: translateX(10px);
            background-color: #f1f1f1;
        }

        .notification-icon {
            font-size: 24px;
            margin-right: 15px;
        }

        .notification-content {
            flex: 1;
        }

        .notification-title {
            font-size: 18px;
            font-weight: bold;
            margin: 0;
        }

        .notification-description {
            font-size: 14px;
            color: #666;
        }

        /* Tooltip */
        .tooltip {
            position: relative;
            display: inline-block;
            cursor: pointer;
        }

        .tooltip .tooltiptext {
            visibility: hidden;
            width: 120px;
            background-color: #6c757d;
            color: #fff;
            text-align: center;
            border-radius: 5px;
            padding: 5px;
            position: absolute;
            z-index: 1;
            bottom: 125%; /* Position above the icon */
            left: 50%;
            margin-left: -60px;
            opacity: 0;
            transition: opacity 0.3s;
        }

        .tooltip:hover .tooltiptext {
            visibility: visible;
            opacity: 1;
        }

        /* حالة مقروءة وغير مقروءة */
        .notification-card.read {
            background-color: #e7f3e7;
        }

        .notification-card.unread {
            background-color: #ffefeb;
        }

    </style>
</head>
<body>

<h2 style="text-align: center; padding-top: 20px;">صفحة الإشعارات</h2>

<!-- زر عرض الإشعارات -->
<div style="text-align: center; padding: 20px;">
    <button id="openModalBtn">عرض الإشعارات</button>
</div>

<!-- نافذة منبثقة تحتوي على الإشعارات -->
<div id="notificationsModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeModalBtn">&times;</span>

        <!-- تصفية الإشعارات -->
        <div class="filter-container">
            <form method="get" action="">
                <label for="filter">تصفية الإشعارات:</label>
                <select name="filter" id="filter" onchange="this.form.submit()">
                    <option value="unread" <?php echo $filter == 'unread' ? 'selected' : ''; ?>>غير مقروءة</option>
                    <option value="read" <?php echo $filter == 'read' ? 'selected' : ''; ?>>مقروءة</option>
                    <option value="all" <?php echo $filter == 'all' ? 'selected' : ''; ?>>الكل</option>
                </select>
            </form>
        </div>

        <!-- الإشعارات -->
        <div id="notificationList">
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="notification-card <?php echo $row['is_read'] ? 'read' : 'unread'; ?>">
                    <div class="notification-icon">ℹ️</div>
                    <div class="notification-content">
                        <h4 class="notification-title"><?php echo $row['message']; ?></h4>
                        <p class="notification-description"><?php echo $row['cause']; ?></p>
                    </div>
                    <div class="tooltip">
                        <!-- أيقونة حالة المقروء أو الغير مقروء -->
                        <?php if ($row['is_read']): ?>
                            <i class="fas fa-check" style="color: #4CAF50;"></i>
                            <span class="tooltiptext">مقروءة</span>
                        <?php else: ?>
                            <i class="fas fa-times" style="color: #F44336;"></i>
                            <span class="tooltiptext">غير مقروءة</span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</div>

<script>
    // الحصول على العناصر من الصفحة
    var modal = document.getElementById("notificationsModal");
    var btn = document.getElementById("openModalBtn");
    var span = document.getElementById("closeModalBtn");

    // فتح النافذة المنبثقة عند الضغط على الزر
    btn.onclick = function() {
        modal.style.display = "block";
    }

    // إغلاق النافذة عند الضغط على "×"
    span.onclick = function() {
        modal.style.display = "none";
    }

    // إغلاق النافذة عند النقر في أي مكان خارج النافذة المنبثقة
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>

</body>
</html>

<?php
$conn->close();
?>
