<?php include "settings_logined.php" ?>
<?php include "add_notfications.php" ?>
<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>أقساطك</title>
    <link rel="icon" href="Images/Logos/People Dollar logo, Money Finances logo.png" type="image/png">
    <link rel="stylesheet" href="clients.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Cairo&display=swap" rel="stylesheet">
    <style>
        .op9, .po9{
            font-weight: bold;
    color: #171742;
        }

        .op2, .po2{
            color: #868395;
    font-weight: 600;
        }
    </style>
</head>

<body>
    <!-- main -->
    <main>
        <!-- header -->
        <?php include "header.php"; ?>

        <script src="clients.js"></script>

        <div class='notifications-container' id='notificationList'>
            <div class="close-list">
                <i class="fas fa-times"></i>
            </div>
            <?php include "notfication-list.php"; ?>
        </div>

        <section class="head">
            <div class="add-clint">
                <button onclick="window.location.href='add_clint.php'" class="add_clint-btn">إضافة عميل +</button>
            </div>

            <div class="search-container">
                <div class="real-search-container">
                    <input type="text" name="serch_input" id="serch_input" class="search-input" dir="rtl" placeholder="أدخل محتوي البحث...">
                    <button class="submit-button" type="submit" onclick="submitSearch()">بحث</button>
                </div>
            </div>
        </section>
        <section class="main" style="margin-bottom: 3em;">

        <table class="styled-table">
    <thead>
        <tr>
            <th>Actions</th>
            <th>كلمة السر</th>
            <th>#</th>
        </tr>
    </thead>
    <tbody>
        <?php
        include "db_connection.php"; 
        $sql = "SELECT * FROM passwords ORDER BY id DESC";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) { ?>
                <tr data-user-id="<?php echo $row['id']; ?>">
                    <td><?php echo $row['password']; ?></td>
                    <td><?php echo $row['id']; ?></td>
                    <td><a class="delete-btn" href="delete_password.php?id=<?php echo $row['id']; ?>">Delete</a> <a href="edit_password.php?id=<?php echo $row['id']; ?>">Edit</a></td>
                    
                </tr>
            <?php }
        } else {
            echo "<tr><td colspan='8'>لا توجد بيانات لعرضها</td></tr>";
        }
        ?>
    </tbody>
</table>


        </section>

    </main>

    <?php 
    include "aside.php";
    ?>

    <div class="over-layer"></div>

    <script>
document.addEventListener('DOMContentLoaded', () => {
    // التعامل مع حذف كلمة السر
    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', () => {
            const id = button.getAttribute('data-id');
            
            // إرسال الطلب إلى السيرفر لحذف كلمة السر
            fetch('delete_password.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id })
            })
            .then(response => response.json())
            .then(data => {
                // تحديد العنصر الذي سيعرض الرسالة
                const responseMessage = document.getElementById('responseMessage');
                
                if (responseMessage) {
                    responseMessage.textContent = data.message;
                }

                // إذا تم الحذف بنجاح، يتم إزالة الصف من الجدول
                if (data.success) {
                    const row = document.getElementById(`row-${id}`);
                    if (row) {
                        row.remove();
                    }

                    // إعادة تحميل الصفحة بعد الحذف
                    location.reload();
                }
            })
            .catch(error => {
                // في حال حدوث خطأ أثناء الطلب
                const responseMessage = document.getElementById('responseMessage');
                if (responseMessage) {
                    responseMessage.textContent = 'حدث خطأ أثناء الحذف!';
                }
            });
        });
    });
});

    </script>
</body>

</html>