<?php
// الاتصال بقاعدة البيانات
include('db_connection.php');

// التحقق من وجود الـ id في الـ GET
if (isset($_GET['id'])) {
    $client_id = $_GET['id'];
    
    // استرجاع بيانات العميل
    $sql_client = "SELECT * FROM clients WHERE id = $client_id";
    $result_client = mysqli_query($conn, $sql_client);
    $client = mysqli_fetch_assoc($result_client);
    
    // استرجاع بيانات الأقساط
    $sql_installments = "SELECT * FROM installments WHERE client_id = $client_id";
    $result_installments = mysqli_query($conn, $sql_installments);
    $installments = mysqli_fetch_assoc($result_installments);
    
    // استرجاع بيانات المُقدمات
    $sql_advances = "SELECT * FROM advances WHERE client_id = $client_id";
    $result_advances = mysqli_query($conn, $sql_advances);
    $advances = mysqli_fetch_assoc($result_advances);
    
    // استرجاع بيانات المؤخرات
    $sql_delays = "SELECT * FROM delays WHERE client_id = $client_id";
    $result_delays = mysqli_query($conn, $sql_delays);
    $delays = mysqli_fetch_assoc($result_delays);
} else {
    echo "لم يتم العثور على العميل.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>تعديل بيانات العميل</title>
</head>
<body>
    <h2>تعديل بيانات العميل: <?php echo $client['first_name'] . ' ' . $client['last_name']; ?></h2>

    <form method="POST" action="update_client.php">
        <!-- بيانات العميل -->
        <h3>بيانات العميل</h3>
        <label>الاسم الأول:</label>
        <input type="text" name="first_name" value="<?php echo $client['first_name']; ?>" required><br><br>

        <label>الاسم الأخير:</label>
        <input type="text" name="last_name" value="<?php echo $client['last_name']; ?>" required><br><br>

        <label>البريد الإلكتروني:</label>
        <input type="email" name="email" value="<?php echo $client['email']; ?>" required><br><br>

        <label>رقم الهاتف:</label>
        <input type="text" name="phone_number" value="<?php echo $client['phone_number']; ?>" required><br><br>

        <label>العنوان:</label>
        <textarea name="address" required><?php echo $client['address']; ?></textarea><br><br>

        <!-- بيانات الأقساط -->
        <h3>بيانات الأقساط</h3>
        <label>المبلغ الإجمالي:</label>
        <input type="text" name="total_amount" value="<?php echo $installments['total_amount']; ?>" required><br><br>

        <label>قيمة القسط:</label>
        <input type="text" name="kest_value" value="<?php echo $installments['kest_value']; ?>" required><br><br>

        <label>المبلغ المدفوع مقدمًا:</label>
        <input type="text" name="upfront" value="<?php echo $installments['upfront']; ?>"><br><br>

        <label>المبلغ المؤجل:</label>
        <input type="text" name="deferred" value="<?php echo $installments['deferred']; ?>"><br><br>

        <label>تاريخ أول دفع:</label>
        <input type="date" name="first_pay_date" value="<?php echo $installments['first_pay_date']; ?>" required><br><br>

        <!-- بيانات المُقدمات -->
        <h3>المُقدمات</h3>
        <label>تاريخ الدفع المقدم:</label>
        <input type="date" name="advance_date" value="<?php echo $advances['advance_date']; ?>"><br><br>

        <label>قيمة الدفع المقدم:</label>
        <input type="text" name="advance_value" value="<?php echo $advances['advance_value']; ?>"><br><br>

        <!-- بيانات المؤخرات -->
        <h3>المؤخرات</h3>
        <label>تاريخ التأخير:</label>
        <input type="date" name="delay_date" value="<?php echo $delays['delay_date']; ?>"><br><br>

        <label>قيمة التأخير:</label>
        <input type="text" name="delay_value" value="<?php echo $delays['delay_value']; ?>"><br><br>

        <label>تاريخ الاستحقاق:</label>
        <input type="date" name="due_date" value="<?php echo $delays['due_date']; ?>"><br><br>

        <!-- زر الحفظ -->
        <button type="submit">تحديث البيانات</button>
    </form>
</body>
</html>
