<?php

// include 'check_session_oi.php';



?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>صفحة العميل</title>
    <link rel="stylesheet" href="add_clint.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Tajawal&display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo&display=swap">
    <link rel="stylesheet" href="responsive.css">
    <style>
        .user-name {
            direction: rtl;
        }
        
        main{
            height: fit-content;
        }
        
        .first-name-group, .last-name-group {
    display: none;
}

input{
        width: 100%;
}
    </style>
</head>
<body>
<!-- main -->
<main>
    <!-- header -->
<?php include "header.php"; ?>


        <div class="titt">
        <h3>إضافة عميل</h3>
        </div>
                
                <div class="left-sec">
            <div class="sign-up_container">
                <div class="real-sign-up_container">

                <form action="new_clint2.php" method="post" id="passwordForm" class="content" enctype="multipart/form-data">
    <div class="upload-container" onclick="document.getElementById('file-upload').click();">
        <input type="file" id="file-upload" name="user_image" accept="image/*" onchange="previewImage(event)" />
        <div class="upload-label">
            <img id="preview" src="Images/Logos/add_clint_igm.png" alt="Upload Icon" />
            <div class="add-icon" id="add-icon">+</div>
        </div>
    </div>

    <script>
        function previewImage(event) {
            var reader = new FileReader();
            reader.onload = function () {
                var output = document.getElementById('preview');
                output.src = reader.result;
                document.getElementById('add-icon').style.display = 'none'; // إخفاء الأيقونة "+" عند اختيار صورة
            };
            reader.readAsDataURL(event.target.files[0]);
        }
    </script>


    <div class="form-group">
    <div class="input-group">
        <!-- <label for="full-name" class="label">الاسم الكامل</label> -->
        <input type="text" name="full_name" id="full_name" placeholder="الاسم الكامل" class="full-name" required oninput="splitName()">
    </div>

    <div class="input-group first-name-group">
        <label for="first-name" class="label">الاسم الأول</label>
        <input type="text" name="first_name" id="first_name" class="first-name" readonly>
    </div>

    <div class="input-group last-name-group">
        <label for="last-name" class="label">الاسم الأخير</label>
        <input type="text" name="last_name" id="last_name" class="last-name" readonly>
    </div>
</div>

<script>
function splitName() {
    const fullName = document.getElementById("full_name").value.trim();
    const firstSpaceIndex = fullName.indexOf(" ");

    if (firstSpaceIndex !== -1) {
        document.getElementById("first_name").value = fullName.substring(0, firstSpaceIndex);
        document.getElementById("last_name").value = fullName.substring(firstSpaceIndex + 1);
    } else {
        document.getElementById("first_name").value = fullName;
        document.getElementById("last_name").value = "";
    }
}
</script>

    <div class="form-group">
    <!-- <div class="input-group">
            <input type="number" name="monthly_income" placeholder="الدخل الشهري" id="monthly_income" class="monthly_income" required>
        </div> -->


        <div class="input-group">
            <input type="text" style="width: 100%;" placeholder="العنوان" name="user_address" id="user_address" class="user_address" required>
        </div>
    </div>

    <div class="form-group">
        <div class="input-group">
            <input type="email" name="user_email" placeholder="البريد الالكتروني" id="user_email" class="user_email" required>
        </div>

        <div class="input-group">
            <input type="number" name="national_id" placeholder="رقم الهوية" id="national_id" class="national_id" required>
        </div>
    </div>

    <div class="form-group">
        <div class="input-group">
            <input type="number" name="phone_number" placeholder="رقم الهاتف" id="phone_number" class="phone_number" required>
        </div>

        <div class="input-group">
            <input type="text" name="profession" placeholder="المهنة" id="profession" class="profession">
        </div>
    </div>

    <div class="form-group">
        <div class="input-group">
            <input type="number" name="monthly_income" placeholder="الدخل الشهري" id="monthly_income" class="monthly_income">
        </div>

        <div class="input-group">
            <input type="date" name="birth_date" id="birth_date" class="birth_date">
        </div>
    </div>

    <hr>
    <br>
    <div class="form-group">
        <div class="input-group">
            <input type="number" name="total_amount" placeholder="المبلغ الإجمالي" id="total_amount" class="total_amount">
        </div>

        <!-- <div class="input-group">
            <input type="date" name="birth_date" id="birth_date" class="birth_date">
        </div> -->
    </div>

    <div class="form-group">
        <div class="input-group">
            <input type="number" placeholder="المؤخر" name="delay" id="delay" class="delay">
        </div>

        
        <div class="input-group">
            <input type="number" name="advance" placeholder="المُقدم" id="advance" class="advance">
        </div>
    </div>

    <div class="form-group">
        <div class="input-group">
            <input type="number" name="kest_value" placeholder="قيمة القسط" id="kest_value" class="kest_value">
        </div>

        <div class="input-group">
            <input type="date" name="first_pay_date" id="first_pay_date" class="first_pay_date">
        </div>
    </div>

    <div class="form-group">
        <div class="input-group">
            <input type="text" name="adition_notes" placeholder="ملاحظات إضافية" id="adition_notes" class="adition_notes">
        </div>

        <!-- <div class="input-group">
            <input type="date" name="birth_date" id="birth_date" class="birth_date">
        </div> -->
    </div>

    <div class="form-group">
        <div class="input-group">
            <input type="text" name="bank_name" placeholder="إسم البنك" id="bank_name" class="bank_name">
        </div>

        <!-- <div class="input-group">
            <input type="date" name="birth_date" id="birth_date" class="birth_date">
        </div> -->
    </div>
    
    




    <div class="form-group form-group-submit">
        <button type="submit" class="submit_data">إنشاء حساب</button>
    </div>
</form>




<script>
$(document).ready(function() {
    function formatState (state) {
        if (!state.id) {
            return state.text;
        }
        var baseUrl = state.element.dataset.image;
        var $state = $(
            '<span><img src="' + baseUrl + '" class="img-flag" style="width: 20px; margin-right: 10px;"/>' + state.text + '</span>'
        );
        return $state;
    };

    $('#bank_select').select2({
        templateResult: formatState,
        templateSelection: formatState
    });
});
</script>


<script>
    document.addEventListener("DOMContentLoaded", function() {
    const passwordInput = document.getElementById('user_password');
    const confirmPasswordInput = document.getElementById('confirm_user_password');
    const errorMessage = document.getElementById('error_message');

    function validatePasswords() {
        if (passwordInput.value !== confirmPasswordInput.value) {
            errorMessage.style.display = 'block'; // عرض رسالة الخطأ
        } else {
            errorMessage.style.display = 'none'; // إخفاء رسالة الخطأ
        }
    }

    // إضافة حدث عند كتابة المستخدم في حقول كلمة المرور
    passwordInput.addEventListener('input', validatePasswords);
    confirmPasswordInput.addEventListener('input', validatePasswords);
});

</script>



<script>
    const passwordForm = document.getElementById('passwordForm');
    const passwordInput = document.getElementById('user_password');
    const confirmPasswordInput = document.getElementById('confirm_user_password');
    const errorMessage = document.getElementById('error_message');

    passwordForm.addEventListener('submit', function(event) {
        // التحقق من مطابقة كلمتي السر
        if (passwordInput.value !== confirmPasswordInput.value) {
            event.preventDefault(); // منع الإرسال إذا كانت كلمتا السر غير متطابقتين
            errorMessage.style.display = 'flex'; // إظهار الرسالة
            passwordInput.value = ''; // تفريغ كلمة السر
            confirmPasswordInput.value = ''; // تفريغ تأكيد كلمة السر
            passwordInput.style.border = '1px solid red'; // تغيير لون الحدود للأحمر
            confirmPasswordInput.style.border = '1px solid red'; // تغيير لون الحدود للأحمر
            errorMessage.textContent = 'كلمتا السر غير متطابقتين';
        } else {
            errorMessage.style.display = 'none'; // إخفاء الرسالة إذا كان كل شيء صحيح
            passwordInput.style.border = ''; // إعادة الحدود الأصلية
            confirmPasswordInput.style.border = ''; // إعادة الحدود الأصلية
        }
    });
</script>

                    
                </div>
            </div>
        </div>


</main>

    <?php 
    include "aside.php";
    ?>
</body>
</html>
