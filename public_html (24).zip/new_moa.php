<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'db_connection.php';

// دالة لتوليد كود العميل الفريد
function generateUniqueCode($conn) {
    do {
        $code = str_pad(rand(0, 9999), 4, '0', STR_PAD_LEFT); // توليد كود عشوائي من 4 أرقام
        $query = "SELECT COUNT(*) FROM clients WHERE clint_code = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $code);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close();
    } while ($count > 0);
    return $code;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $client_id = $_GET['id'];
    $total_amount = $_POST['total_amount'];
    $advance = $_POST['advance'];
    $delay = $_POST['delay'];
    $first_pay_date = $_POST['first_pay_date'];
    $kest_value = $_POST['kest_value'];
    $adition_notes = $_POST['adition_notes'];
    $bank_name = $_POST['bank_name'];
    $user_email = $_POST['email']; // تعريف البريد الإلكتروني المستخدم

    // التحقق من وجود بريد إلكتروني مكرر
    $email_check_query = "SELECT COUNT(*) FROM clients WHERE email = ?";
    $stmt = $conn->prepare($email_check_query);
    $stmt->bind_param("s", $user_email);
    $stmt->execute();
    $stmt->bind_result($email_exists);
    $stmt->fetch();
    $stmt->close();

    if ($email_exists > 0) {
        header("Location: email_exists.html");
        exit();
    }

    // توليد كود فريد للعميل
    $clint_code = generateUniqueCode($conn);

    // إدخال بيانات القسط الرئيسي في جدول installments
    $log_query = "INSERT INTO installments (total_amount, kest_value, upfront, deferred, first_pay_date, client_id, additional_notes, bank_name) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $log_stmt = $conn->prepare($log_query);
    $advance_date = $first_pay_date;
    if ($log_stmt) {
        $log_stmt->bind_param("ddddsiss", $total_amount, $kest_value, $advance, $delay, $first_pay_date, $client_id, $adition_notes, $bank_name);

        if ($log_stmt->execute()) {
            $installment_id = $conn->insert_id;

            // إدخال بيانات المقدم
// الخطوة 1: إدراج التاريخ في جدول dates
$date_query = "INSERT INTO dates (date) VALUES (?)";
$date_stmt = $conn->prepare($date_query);

if ($date_stmt) {
    // تأكد من أن التاريخ المدخل في تنسيق صحيح
    $first_pay_date = date("Y-m-d", strtotime($first_pay_date)); // تحويل التاريخ إلى تنسيق YYYY-MM-DD
    $date_stmt->bind_param("s", $first_pay_date); // نوع البيانات هنا 's' لأنه تاريخ
    
    if ($date_stmt->execute()) {
        // جلب الـ id الخاص بالصف الذي تم إدراجه في جدول dates
        $date_id = $conn->insert_id; // هذا سيعيد الـ id الأخير الذي تم إدراجه في جدول dates
    } else {
        echo 'Error in date insertion: ' . $conn->error;
        $date_stmt->close();
        exit;
    }
    $date_stmt->close();
} else {
    echo 'Error preparing date statement: ' . $conn->error;
    exit;
}

// الخطوة 2: إدراج البيانات في جدول advances مع استخدام date_id
$advance_query = "INSERT INTO advances (installment_id, client_id, advance_value, advance_date, is_paid, paid_at) 
                  VALUES (?, ?, ?, ?, ?, ?)";
$advance_stmt = $conn->prepare($advance_query);

if ($advance_stmt) {
    $is_paid = 1;
    $paid_at = date("Y-m-d H:i:s");

    // ربط المتغيرات مع الاستعلام
    $advance_stmt->bind_param("iiidsi", $installment_id, $client_id, $advance, $date_id, $is_paid, $paid_at);

    if (!$advance_stmt->execute()) {
        echo 'Error in advance insertion: ' . $conn->error;
    }
    $advance_stmt->close();
} else {
    echo 'Error preparing advance statement: ' . $conn->error;
}


            // إدخال الأقساط الفرعية
            $remaining_amount = $total_amount - ($advance + $delay);
            $x = ceil($remaining_amount / $kest_value);
            $last_installment_value = $remaining_amount - ($kest_value * ($x - 1));
            $current_date = $first_pay_date;

            $sub_query = "INSERT INTO sub_installments (installment_id, installment_value, client_id, is_paid, paid_at, sub_installment_date) 
                          VALUES (?, ?, ?, ?, ?, ?)";
            $sub_stmt = $conn->prepare($sub_query);

            if ($sub_stmt) {
                for ($i = 1; $i <= $x; $i++) {
                    $installment_value = ($i == $x) ? $last_installment_value : $kest_value;
                    $is_paid = 0;
                    $paid_at = null;

                    $sub_installment_date = date("Y-m-d", strtotime("+1 month", strtotime($current_date)));
                    $current_date = $sub_installment_date;

                    $sub_stmt->bind_param("idisss", $installment_id, $installment_value, $client_id, $is_paid, $paid_at, $sub_installment_date);

                    if (!$sub_stmt->execute()) {
                        echo 'Error in sub installment insertion: ' . $conn->error;
                        break;
                    }
                }
                $sub_stmt->close();

                // حساب تاريخ delay_date بناءً على آخر شهر في الأقساط الفرعية
                $last_installment_date = $current_date;
                $delay_date = date("Y-m-d", strtotime("+1 month", strtotime($last_installment_date)));

                // إدخال بيانات المؤخر
                $delay_query = "INSERT INTO delays (installment_id, client_id, delay_value, delay_date, is_paid) 
                                VALUES (?, ?, ?, ?, ?)";
                $delay_stmt = $conn->prepare($delay_query);

                if ($delay_stmt) {
                    $is_paid = 0;
                    $delay_stmt->bind_param("iidsi", $installment_id, $client_id, $delay, $delay_date, $is_paid);

                    if (!$delay_stmt->execute()) {
                        echo 'Error in delay insertion: ' . $conn->error;
                    }
                    $delay_stmt->close();
                }
            }

            header("Location: success.html");
            exit;
        } else {
            echo 'Error in installment insertion: ' . $conn->error;
        }
        $log_stmt->close();
    }
}

$conn->close();
?>
