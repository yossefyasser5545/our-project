<?php
include "db_connection.php";

// جلب حالة القسط بناءً على user_id
$user_id = 1; // قم بتغيير هذا إلى المعرف الفعلي للمستخدم
$sql = "SELECT is_paid, payment_date FROM installments WHERE user_id = $user_id LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $is_paid = $row['is_paid'];
    $payment_date = $row['payment_date'];

    // عرض حالة القسط وتنفيذ الحدث إذا كان مدفوعًا
    if ($is_paid) {
        echo "<h1>القسط مدفوع</h1>";
        echo "<p style='color: green;'>تم دفع القسط بتاريخ: $payment_date</p>";
        // تنفيذ الحدث - على سبيل المثال: رسالة شكر
        echo "<script>alert('شكراً لتسديد القسط!');</script>";
    } else {
        echo "<h1>القسط غير مدفوع</h1>";
        echo "<p style='color: red;'>يرجى تسديد القسط في أقرب وقت ممكن.</p>";
    }
} else {
    echo "<h1>لا توجد بيانات للقسط لهذا المستخدم.</h1>";
}

// إغلاق الاتصال بقاعدة البيانات
$conn->close();
?>
