<?php
// الاتصال بقاعدة البيانات
include('db_connection.php');

// التحقق إذا كان الـ id موجوداً في الـ URL
if (isset($_GET['id'])) {
    $client_id = $_GET['id'];

    // استرجاع بيانات العميل من قاعدة البيانات
    $sql = "SELECT * FROM clients WHERE id = $client_id";
    $result = mysqli_query($conn, $sql);

    // التحقق إذا كانت البيانات موجودة
    if (mysqli_num_rows($result) > 0) {
        $client = mysqli_fetch_assoc($result);
    } else {
        echo "العميل غير موجود!";
        exit();
    }

    // التحقق إذا تم إرسال التحديث
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // الحصول على القيم من النموذج
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $email = $_POST['email'];
        $phone_number = $_POST['phone_number'];
        $address = $_POST['address'];
        $image_path = $_POST['image_path'];
        $clint_code = $_POST['clint_code'];
        $national_id = $_POST['national_id'];
        $profession = $_POST['profession'];
        $birth_date = $_POST['birth_date'];
        $monthly_income = $_POST['monthly_income'];

        // تحديث بيانات العميل في قاعدة البيانات
        $update_sql = "UPDATE clients SET 
                        first_name = '$first_name', 
                        last_name = '$last_name', 
                        email = '$email', 
                        phone_number = '$phone_number', 
                        address = '$address', 
                        image_path = '$image_path', 
                        clint_code = '$clint_code', 
                        national_id = '$national_id', 
                        profession = '$profession', 
                        birth_date = '$birth_date', 
                        monthly_income = '$monthly_income' 
                       WHERE id = $client_id";

        if (mysqli_query($conn, $update_sql)) {
            echo "تم تحديث البيانات بنجاح!";
        } else {
            echo "حدث خطأ أثناء التحديث: " . mysqli_error($conn);
        }
    }
} else {
    echo "معرف العميل غير موجود في الـ URL.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>تعديل بيانات العميل</title>
</head>
<body>
    <h1>تعديل بيانات العميل</h1>
    
    <!-- نموذج تعديل بيانات العميل -->
    <form action="update_client.php?id=<?php echo $client['id']; ?>" method="POST">
        <label for="first_name">الاسم الأول:</label>
        <input type="text" name="first_name" value="<?php echo $client['first_name']; ?>" required><br><br>

        <label for="last_name">الاسم الأخير:</label>
        <input type="text" name="last_name" value="<?php echo $client['last_name']; ?>" required><br><br>

        <label for="email">البريد الإلكتروني:</label>
        <input type="email" name="email" value="<?php echo $client['email']; ?>" required><br><br>

        <label for="phone_number">رقم الهاتف:</label>
        <input type="text" name="phone_number" value="<?php echo $client['phone_number']; ?>" required><br><br>

        <label for="address">العنوان:</label>
        <textarea name="address" required><?php echo $client['address']; ?></textarea><br><br>

        <label for="image_path">مسار الصورة:</label>
        <input type="text" name="image_path" value="<?php echo $client['image_path']; ?>"><br><br>

        <label for="clint_code">كود العميل:</label>
        <input type="text" name="clint_code" value="<?php echo $client['clint_code']; ?>" required><br><br>

        <label for="national_id">رقم الهوية:</label>
        <input type="text" name="national_id" value="<?php echo $client['national_id']; ?>" required><br><br>

        <label for="profession">المهنة:</label>
        <input type="text" name="profession" value="<?php echo $client['profession']; ?>"><br><br>

        <label for="birth_date">تاريخ الميلاد:</label>
        <input type="date" name="birth_date" value="<?php echo $client['birth_date']; ?>"><br><br>

        <label for="monthly_income">الدخل الشهري:</label>
        <input type="number" step="0.01" name="monthly_income" value="<?php echo $client['monthly_income']; ?>"><br><br>

        <button type="submit">تحديث البيانات</button>
    </form>
    
    <a href="client_list.php">رجوع إلى قائمة العملاء</a>
</body>
</html>
