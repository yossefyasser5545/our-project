<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>التحقق من كلمة السر</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #1E3A8A; /* الأزرق الغامق */
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .form-container {
            background-color: #334155; /* خلفية داكنة */
            padding: 30px;
            border-radius: 8px;
            width: 300px;
            text-align: center;
        }
        input[type="password"] {
            width: 94%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            background-color: #2D3748; /* لون خلفية الحقل */
            color: white;
            font-size: 16px;
        }
        input[type="submit"] {
            background-color: #4C51BF; /* أزرق فاتح */
            color: white;
            padding: 10px;
            width: 100%;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #3B42A1;
        }
        .error {
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>التحقق من كلمة السر</h2>
        <form action="verify_password.php" method="POST">
            <input type="password" name="password" placeholder="أدخل كلمة السر" required>
            <input type="submit" value="تحقق">
        </form>
        <?php
            if (isset($_GET['error'])) {
                echo '<p class="error">كلمة السر غير صحيحة!</p>';
            }
        ?>
    </div>
</body>
</html>
