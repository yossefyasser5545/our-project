<?php
// Database connection details
$servername = "localhost";
$username = "u563506956_infooo";
$password = "#A9!U0kz1tS6";
$database = "u563506956_Kest";

// Create a connection
$conn = new mysqli($servername, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Uncomment the line below for testing the connection
// echo "Connected successfully";
?>
