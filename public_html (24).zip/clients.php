<?php include "logined.php" ?>
<?php include "add_notfications.php" ?>
<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>أقساطك</title>
    <link rel="icon" href="Images/Logos/People Dollar logo, Money Finances logo.png" type="image/png">
    <link rel="stylesheet" href="clients.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Arabic&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Cairo&display=swap" rel="stylesheet">
</head>

<body>
    <!-- main -->
    <main>
        <!-- header -->
        <?php include "header.php"; ?>

        <script src="clients.js"></script>

        <div class='notifications-container' id='notificationList'>
            <div class="close-list">
                <i class="fas fa-times"></i>
            </div>
            <?php include "notfication-list.php"; ?>
        </div>

        <section class="head">
            <div class="add-clint">
                <button onclick="window.location.href='add_clint.php'" class="add_clint-btn">إضافة عميل +</button>
            </div>

            <div class="search-container">
                <div class="real-search-container">
                    <input type="text" name="serch_input" id="serch_input" class="search-input" dir="rtl" placeholder="أدخل محتوي البحث...">
                    <button class="submit-button" type="submit" onclick="submitSearch()">بحث</button>
                </div>
            </div>
        </section>
        <section class="main" style="margin-bottom: 3em;">

        <table class="styled-table">
    <thead>
        <tr>
            <th></th>
            <th></th>
            <!-- <th>Actions</th> -->
            <th>الوكيل</th>
            <th>الدخل الشهري</th>
            <th>رقم الهوية</th>
            <th>رقم العميل</th>
            <th>اسم العميل</th>
            <th>كود العميل</th>
            <!-- <th>حذف</th> -->
        </tr>
    </thead>
    <tbody>
        <?php
        include "db_connection.php"; 
        $sql = "SELECT * FROM clients ORDER BY id DESC";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) { ?>
                <tr data-user-id="<?php echo $row['id']; ?>">
                    <td><i onclick="toggleInstallments(<?php echo $row['id']; ?>, this)" style='cursor: pointer;' subs-rotate='s90' class='fas gfjkn fa-play rotate-icon'></i></td>
                    <!-- <td><i onclick="deleteClient(? echo $row['id']; ?)" class="fa fa-trash"></i></td> -->
                    <td><a class="details-link" href="details.php?client_id=<?php echo $row['id']; ?>">Go</a></td>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['monthly_income']; ?></td>
                    <td><?php echo $row['national_id']; ?></td>
                    <td><?php echo $row['phone_number']; ?></td>
                    <td><?php echo $row['first_name']; ?> <?php echo $row['last_name']; ?></td>
                    <td><?php echo $row['clint_code']; ?></td>
                    
                </tr>
                <tr class="installments-row" id="installments-<?php echo $row['id']; ?>" style="display: none;">
                    <td colspan="10">
                        <table border="1">
                            <tr style="background-color: #585d89; color: #ffffff; padding: 12px 15px; text-align: center; font-size: 14px; font-weight: 100; border: solid 2px #b9bdcc;">
                                <!-- <th>تفاصيل السداد</th> -->
                                <th>رقم القرض</th>
                                <!-- <th>المبلغ الواصل</th>
                                <th>المبلغ المتبقي</th> -->
                                <th>التاريخ الأول للقسط</th>
                                <th>قيمة القسط</th>
                                <th>ملاحظات إضافية</th>
                                <th>مبلغ المُقدم</th>
                                <th>مبلغ المؤخر</th>
                                <th>المبلغ الإجمالي</th>
                            </tr>
                            <?php 
                            $user_id = $row['id']; 
                            $query = "SELECT * FROM installments WHERE client_id = $user_id";  // الاستعلام لإرجاع الأقساط الخاصة بالمستخدم
                            $installments_result = $conn->query($query);

                            if ($installments_result->num_rows > 0) {
                                while ($installment = $installments_result->fetch_assoc()) {
                                    $remaining_amount = $installment['total_amount'] - $installment['kest_value'];
                                    echo "<tr>
                                            <td>{$installment['id']}</td>
                                            <td>{$installment['first_pay_date']}</td>
                                            <td>{$installment['kest_value']}</td>
                                            <td>{$installment['additional_notes']}</td>
                                            <td>{$installment['upfront']}</td>
                                            <td>{$installment['deferred']}</td>
                                            <td>{$installment['total_amount']}</td>
                                        </tr>";
                                }
                            } else {
                                echo "<tr><td colspan='12'>لا توجد أقساط لهذا المستخدم.</td></tr>";
                            }
                            ?>
                        </table>
                    </td>
                </tr>
            <?php }
        } else {
            echo "<tr><td colspan='8'>لا توجد بيانات لعرضها</td></tr>";
        }
        ?>
    </tbody>
</table>


        </section>

    </main>

    <?php 
    include "aside.php";
    ?>

    <div class="over-layer"></div>

    <script>
            document.querySelector('.close-list').addEventListener("click", function(){
        removePopupFromURL();
         document.getElementById('notificationList').style.display = 'none';
        document.querySelector('.over-layer').style.display = "none";
});     
    </script>
</body>

</html>