<?php
include "db_connection.php";

// التحقق من وجود الـ ID
if (isset($_POST['id'])) {
    $id = $_POST['id'];

    // تحديث حالة الإشعار ليصبح مقروءًا
    $sql = "UPDATE notifications SET is_read = 1 WHERE id = $id";
    if ($conn->query($sql) === TRUE) {
        echo "تم التحديث بنجاح";
    } else {
        echo "خطأ: " . $conn->error;
    }
}

$conn->close();
?>
