<?php include "settings_logined.php" ?>
<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إنشاء كلمة سر</title>
    <style>
        /* تنسيق الصفحة */
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            padding: 20px;
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-size: 14px;
            color: #555;
            margin-bottom: 5px;
            text-align: right;
        }

        input[type="password"] {
            width: 100%;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ddd;
            border-radius: 5px;
            outline: none;
            transition: border-color 0.3s;
        }

        input[type="password"]:focus {
            border-color: #007bff;
        }

        .strength-indicator {
            text-align: left;
            font-size: 12px;
            margin-top: 5px;
            color: #888;
        }

        button {
            background-color: #007bff;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            width: 100%;
        }

        button:hover {
            background-color: #0056b3;
        }

        .message {
            margin-top: 15px;
            font-size: 14px;
            color: green;
        }

        .error {
            color: red;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>إنشاء كلمة سر</h1>
        <form id="passwordForm">
            <div class="form-group">
                <label for="password">كلمة السر</label>
                <input type="password" id="password" placeholder="أدخل كلمة السر" required>
                <div class="strength-indicator" id="strengthIndicator">قوة كلمة السر: ضعيفة</div>
            </div>
            <button type="submit">إنشاء</button>
            <div class="message" id="message"></div>
        </form>
    </div>

    <script>
        const passwordInput = document.getElementById("password");
        const strengthIndicator = document.getElementById("strengthIndicator");
        const form = document.getElementById("passwordForm");
        const message = document.getElementById("message");

        // تحديث قوة كلمة السر
        passwordInput.addEventListener("input", () => {
            const value = passwordInput.value;
            let strength = "ضعيفة";
            let color = "red";

            if (value.length >= 8 && /[A-Z]/.test(value) && /[0-9]/.test(value) && /[@$!%*?&#]/.test(value)) {
                strength = "قوية جدًا";
                color = "green";
            } else if (value.length >= 6 && /[A-Z]/.test(value) && /[0-9]/.test(value)) {
                strength = "متوسطة";
                color = "orange";
            }

            strengthIndicator.textContent = `قوة كلمة السر: ${strength}`;
            strengthIndicator.style.color = color;
        });

        // التعامل مع إرسال النموذج
        form.addEventListener("submit", (e) => {
            e.preventDefault();
            const password = passwordInput.value;

            if (password.length < 6) {
                message.textContent = "كلمة السر يجب أن تكون أطول من 6 أحرف.";
                message.className = "message error";
                return;
            }

            fetch("create_password.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ password })
            })
            .then(response => response.json())
            .then(data => {
                message.textContent = data.message;
                message.className = "message";
            })
            .catch(() => {
                message.textContent = "حدث خطأ أثناء إنشاء كلمة السر.";
                message.className = "message error";
            });
        });
    </script>
</body>
</html>
